"""Leitura dos arquivos enviados: tipo, texto das planilhas, identidade da loja e período.

A trava de loja é feita aqui, em código: os relatórios exportados do portal do iFood trazem o
"Id da loja" e/ou o "Nome da loja". Todos os arquivos precisam ser da mesma loja, e essa loja
precisa ser a vinculada à conta.
"""
import csv, io, re, unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime

EXT_TEXTO = {".csv", ".txt", ".xlsx", ".xls"}
EXT_IMAGEM = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}
EXT_PDF = {".pdf"}


class ErroArquivos(Exception):
    """Problema que o cliente consegue corrigir reenviando os arquivos."""


def norm(s) -> str:
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", s)).strip()


@dataclass
class Arquivo:
    nome: str
    tipo: str  # texto | imagem | pdf
    dados: bytes
    midia: str = ""
    texto: str = ""
    linhas: list = field(default_factory=list)  # list[dict] para planilhas
    cabecalho: list = field(default_factory=list)


def _ler_planilha(nome: str, dados: bytes):
    ext = "." + nome.rsplit(".", 1)[-1].lower()
    if ext in (".xlsx", ".xls"):
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(dados), read_only=True, data_only=True)
        linhas = []
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                if any(c is not None for c in row):
                    linhas.append(["" if c is None else str(c) for c in row])
        texto = "\n".join(";".join(r) for r in linhas)
    else:
        texto = dados.decode("utf-8-sig", errors="replace")
        try:
            dial = csv.Sniffer().sniff(texto[:4000], delimiters=",;\t")
        except csv.Error:
            dial = csv.excel
        linhas = list(csv.reader(io.StringIO(texto), dial))
    linhas = [l for l in linhas if any(c.strip() for c in l)]
    if not linhas:
        return texto, [], []
    cab = [c.strip() for c in linhas[0]]
    # colunas repetidas (o iFood repete "Período") ganham sufixo
    vistos = {}
    for i, c in enumerate(cab):
        if c in vistos:
            vistos[c] += 1
            cab[i] = f"{c}.{vistos[c]}"
        else:
            vistos[c] = 0
    dic = [dict(zip(cab, l)) for l in linhas[1:]]
    return texto, cab, dic


def carregar(arquivos: list[tuple[str, bytes]], max_mb: int) -> list[Arquivo]:
    out = []
    for nome, dados in arquivos:
        if not dados:
            continue
        if len(dados) > max_mb * 1024 * 1024:
            raise ErroArquivos(f'O arquivo "{nome}" passa de {max_mb} MB.')
        ext = "." + nome.rsplit(".", 1)[-1].lower() if "." in nome else ""
        if ext in EXT_TEXTO:
            texto, cab, linhas = _ler_planilha(nome, dados)
            out.append(Arquivo(nome, "texto", dados, "text/plain", texto[:120_000], linhas, cab))
        elif ext in EXT_IMAGEM:
            out.append(Arquivo(nome, "imagem", dados, EXT_IMAGEM[ext]))
        elif ext in EXT_PDF:
            out.append(Arquivo(nome, "pdf", dados, "application/pdf"))
        else:
            raise ErroArquivos(f'Formato não aceito: "{nome}". Envie CSV, XLSX, PNG, JPG ou PDF.')
    if not out:
        raise ErroArquivos("Nenhum arquivo recebido.")
    return out


# ------------------------------------------------------------------ identidade da loja
def _col(cab, *alvos):
    alvos = [norm(a) for a in alvos]
    return [c for c in cab if norm(re.sub(r"\.\d+$", "", c)) in alvos]


def identidade(arquivos: list[Arquivo]) -> dict:
    ids, nomes, ufs, cidades = set(), set(), set(), set()
    for a in arquivos:
        if a.tipo != "texto":
            continue
        for c in _col(a.cabecalho, "Id da loja", "ID da loja", "Id loja", "Merchant id"):
            ids |= {l[c].strip() for l in a.linhas if l.get(c, "").strip()}
        for c in _col(a.cabecalho, "Nome da loja"):
            nomes |= {l[c].strip() for l in a.linhas if l.get(c, "").strip()}
        for c in _col(a.cabecalho, "Estado (UF)", "UF"):
            ufs |= {l[c].strip() for l in a.linhas if l.get(c, "").strip()}
        for c in _col(a.cabecalho, "Cidade"):
            cidades |= {l[c].strip() for l in a.linhas if l.get(c, "").strip()}
    ids = {re.sub(r"\.0$", "", i) for i in ids}
    return {"ids": ids, "nomes": nomes, "ufs": ufs, "cidades": cidades}


def conferir_loja(ident: dict, loja_id_conta: str | None, loja_nome_conta: str | None) -> str:
    """Devolve o ID da loja dos arquivos ou levanta ErroArquivos."""
    ids, nomes = ident["ids"], ident["nomes"]
    if not ids:
        raise ErroArquivos("Não encontrei o ID da loja nos arquivos. Inclua pelo menos o relatório de Vendas "
                           "exportado do Portal do Parceiro (CSV), que traz a coluna \"Id da loja\".")
    if len(ids) > 1:
        raise ErroArquivos(f"Os arquivos são de mais de uma loja (IDs {', '.join(sorted(ids))}). "
                           "Cada conta gera relatórios de uma única loja.")
    if len({norm(n) for n in nomes}) > 1:
        raise ErroArquivos("Os arquivos trazem nomes de lojas diferentes: " + "; ".join(sorted(nomes)) + ".")
    loja = next(iter(ids))
    if not re.fullmatch(r"[0-9]{3,12}|[0-9a-fA-F-]{32,36}", loja):
        raise ErroArquivos(f"O ID da loja nos arquivos ({loja}) não está no formato do iFood.")
    if not nomes:
        raise ErroArquivos("Não encontrei o nome da loja nos arquivos. Envie o relatório de Vendas exportado do "
                           "Portal do Parceiro sem alterações (ele traz as colunas \"Id da loja\" e \"Nome da loja\").")
    if loja_id_conta and loja != loja_id_conta:
        raise ErroArquivos(f"Estes arquivos são da loja {loja}, mas sua conta está vinculada à loja "
                           f"{loja_id_conta}. Cada conta gera relatórios de uma única loja.")
    if loja_nome_conta and nomes:
        n = norm(next(iter(nomes)))
        if n and norm(loja_nome_conta) and n != norm(loja_nome_conta):
            raise ErroArquivos(f"O nome da loja nos arquivos ({next(iter(nomes))}) não bate com a loja da conta.")
    return loja


# ------------------------------------------------------------------ período
def periodos(arquivos: list[Arquivo]) -> set[tuple[date, date]]:
    achados = set()
    for a in arquivos:
        if a.tipo != "texto":
            continue
        for c in _col(a.cabecalho, "Período", "Periodo"):
            for l in a.linhas:
                m = re.match(r"\s*(\d{2}/\d{2}/\d{4})\s*-\s*(\d{2}/\d{2}/\d{4})", l.get(c, ""))
                if m:
                    achados.add(tuple(datetime.strptime(x, "%d/%m/%Y").date() for x in m.groups()))
    return achados


def conferir_periodo(achados: set, ini: date, fim: date, tolerancia_dias=1):
    """Planilhas com coluna Período precisam cobrir o período pedido (com 1 dia de folga).
    Também se aceita o período imediatamente anterior, de mesmo tamanho, usado nas comparações."""
    from datetime import timedelta
    dur = fim - ini
    ant_fim = ini - timedelta(days=1)
    validos = [(ini, fim), (ant_fim - dur, ant_fim)]
    perto = lambda p, v: abs((p[0] - v[0]).days) <= tolerancia_dias and abs((p[1] - v[1]).days) <= tolerancia_dias
    errados = [p for p in achados if not any(perto(p, v) for v in validos)]
    if errados:
        f = lambda d: d.strftime("%d/%m/%Y")
        raise ErroArquivos("Alguns relatórios estão em outro período (" +
                           ", ".join(f"{f(a)} a {f(b)}" for a, b in sorted(errados)) +
                           f"). Exporte todos de {f(ini)} a {f(fim)}.")
