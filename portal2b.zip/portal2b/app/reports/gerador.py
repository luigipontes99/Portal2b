#!/usr/bin/env python3
"""Gera o Fechamento Mensal 2bProud (PDF, Carta) a partir de um JSON.

uso:  python3 fechamento.py dados.json [pasta_saida] [--logo logo.png]
saída: Fechamento_<Mes>_<Loja>_2bProud.pdf  (+ a pasta _build com HTML e gráficos)

Requisitos: matplotlib, playwright (Chromium em /opt/pw-browsers), qpdf ou poppler (pdfseparate/pdfunite).
"""
import json, sys, re, os, html, shutil, subprocess, pathlib, unicodedata

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch

LOGO_B64 = "iVBORw0KGgoAAAANSUhEUgAAAJYAAACxCAMAAAARdrReAAAAkFBMVEVWVlpmZmYvLy/p6eqdnaAwLzH9/f1VVVa+vsB8fIFdXV6srKyenp81NjeMjI03NzqAf4M9PEHAvsIoKGPKyss9PUFAP0M9PUE+QEN/gIR/f7+qqv+/wMM/Q0NEP0h/fz9+foCAfn6AfoKqqlWAgH4AAACop6q2trjGxsiHh4uWlploZ2vn5+jW1th1dXlWVlrDQKknAAAAMHRSTlPyCBT67lcBpP39XASfmG7x/vf+D7eg+Vv9/wQD/0g8BG/fiwPfAP7+/v7+/f79/fyPgCJIAAATtElEQVR4nM2bh3bjvLGAAZISi2RrvTV/kntzSwgQYHv/t8sUAARIymUtr4Vz1itbEvVx+gwg0d7lEp8NsL/uECvL7hBLtuUdYsmjVE0r7w3r2J67u8RSurw7LAnCsneHJVup7xLr3GnAOt4VlmwbpdXdYR3b4uv9YUEk7cC07gxLtt80LANY9xTlQYUdmJa5L2md2nLUqrL3pUTwwk4r1OE9Yck2051SlSKsuwmnYFgjGBb44T1hndrziG6IpmUObXYfWKe2AXMHYSnAmg53Ii2kwtigSYf9nVSnjsoJy/btXWCdWtmRYbGw0OLvAAtqrDFnKnU/WCirQVdVEBY64qdjSaLqKt15YaHFfzYWyaqDBVydLRBLQGj9ZKwj+CBRdZ0elS1UUdiH9rMDREJVWVUopSCYtp+LdWwfB0fVdaO1SKXm9nOxQFXnIXdQVa4sQmEhf/pMLAlU+eipRs1UisLD52Gd2iwPVN3YOSpFfvhZWBKNPR8XLE8FOsw+DQsU+DgO4+i5BvJBXBBL5WdhndCsiIqxBm9YmvLh52CBAmUOdjV6roENC5P1xAb/CVggqsfBQyFWRAUGz8L601gSPNArkLFGMncqbHTthfWHscjWgSpfqIbCQ2nlLevPYoFVkajyhSrPA5SusLf481goqhyohjxY/AAa9FQd1A6e6s9hwSeCqPJhiKnyharSc3YMr/5DWKA/sqrBYRHZIquqqjoT7P2PYUFUaPKcqYCLrSvvjIPC2lSVEdUfwQIoCTXM4Bfr0FNVWEF0oML4LR+Phfo7j/lCheIaB8g4gQrWFKvw47HIqPIECrGGwTKVKyFsosKPxkKoZg2FgaszKpbVknXalgquj8Q67ULh0uyCvtxKDOuDCxu8/OP3Hah8UDaG6ro+MizZNh/XkEnsE5p82KPqUlGtqI6ykB+ERVAbQ/eiIrPqPNaITngKbz21Z9N+CBba+RUoFJWlTLM0F1PshKBC/SFYCIXJbxfKiWpRIFEtTihbqbS4PRZ+glwFzwCFoqI6plqo+iSMHtuzpp7sllikvea8Z+eUcaxRKyo9J1RgWJ268djtxCY17DGx/nx1nFDJ6ApQZGhu92+FhVfPWHt7/pdrY5RKsMZRQRRNZNV0ulK2uZW0nPawSh/3jcrUdk3VGbGikh1uJ5rsNliL9rDg3AiLoIy1XoUViwpdMLkKUuEI3NxkNIJM4Hu+9dsUC+B+k4OKqVTftLFdHUGDHe4XKCJ6H9aJcsx31F7nmpk8hQL3Q6jCq7By0UpkMRRt23U0Aueu7D1YLnIOOBBaGtKkCmVJralU/9Am9RXJCmM/vPbwrtmpZO2BKXUx1OhC6YhPGIZiKq/BURsBcSGiwrkgWjtOdRVZ/O9inXyFMHpvXxZVn/mgA1SR+KCCYJWICueCeG+6q6xi0/o9LA5S3TKPTbBGpFWJpJysQFhqKrP2GJvVsZUFXghVCC/83dkpl1Lge2OURmIuhKons6ECYelarET197b9H94w0BDhlTLNb81OXSkFgoqT2wKGz1hkcliRrDptUX/H+GrYFQ1kCKxCNf3O7JR8DyNn5xvPlApMHbRXG5PKiuq+ys4PWSoq7GpZVNAp8pirfHstzwEBtecnB6m4SFCTCVBKLVTaijUUTSWcfWo94i1oc3grFkJJsPNuGf0k0hrQ9yKoICp8uel/HFZQqL8OwzAbFrxMYQn4ttmpPHF9V0VQpBomy0l7DLWlAvUBlIz8jxrIYhjcVLdyClDNm2ankgQOkTCEoIULrgpqDUwOanFBZXpUn/yW3iP5sh8251VBV5v8K16FxVCdir3dDaU0aA8tykOtqdREhr6WVOahEKsaXI+2TClfgZWRFYCkgloWMHBAsJt+A+VfWzNU3DQf2RqGMACvxo7nEXoKg7eXsf4BAod8FUEFrA4C57QwBSonLNNj8IwrBelbkDBrxs2xzkXbN4x0v6FpQiC0SiVYSlUoqBjK2pjKmrk8tIn64iJ2MayBrB3ngSCsV2LhPojuCtyuTbgUXK8Api87krLI1FOYihvTow/Fw+gqWR6Aq8J5jo26oGexMhKVQlNJddiNlRH9VNd7WIWZtoI6kfYgkAwj9UE5y2rMmapbDZOew0JTh6BjU6xCYR0AZj7VW2EVi6AWKFJe9lj4an9wc0reWPEVT5+9CgtusCn+GTzLcRVwCfhggEKqL2tRgaAwcrbHZQQTLMq3IG7OPILotA2FGO/ov4gF5I3SgYp8viig+jDzjFDItRbWND8d1hbVeovCIWCeu6l8znsF1tVhUF2ILC7CrmFhyahtkAIZvVUdQzFWHZkWCsorb4HiVu07yyl3VG7DZ6A22ydW3actxxUs2WaFTuwY7uwrhOzeQyHVIizTs/JiQUlSXkeVtceieTz8jnNKG3Voq0HzFSwwK4iGqdd3BIVrgzXNFDc3MerRFfu+gxzdtgpUM8aPSSqMDb6eeR5LeioPZghK9DGWN61JbJRH+Qp7Wl/sE5b/wfVrEcnKrMbf+1hIZRNjrvQknKgiLsd0WDH5tIfF/rbQH7hPCzkMqR6iKeVVLKQy8VJo6KLfYE09MyX1gdtLybHY/7ruP6hP67En8lggrelhLas9LJJVZM2WoTZY/XzhaJCt3k6VWaXiUSQlP2qJJm6JQrrvqv5hZVe7WEBlY1Fp1YtZwEqw+l5gFdxmqyvSBmuHrZVehNVRmsGiuu/9QMLXILpfW/suFoQPa+qVqDZcLudtZI8xWA9dqPSr6qsv9EeLuWGZk7haZj5sNbjFgnhlbahV/lIoKljEFZjWxUFYuG0/MlTchoDxUxKlu13GJPCMTSdvV7FOrQC78hFJGUFUs6MSi6B2BE/pqqNKOWgJig1wyBpTQ3BsX7JVCidvu1QrLNmWFuMkctVWTZ5q9lqcrwmK01Wl07IM6ldM7JhEa5O2RJoGN9dWgoXmXjNWXRdqgXLiEk22Z1HuvRmUZklZBkV6wUyYE5iq8JYFTVq4v+c9Ea4MAZKhJmWRapEWQP1qkypqRSUtKs+XQJCsQHl0MwD1JQRmX3Pj4MZf4gVPPKEK8c7+mmpSoAjy6vuyaWPtnY7JZf7VSiwQiyWDQrX5BFCT0x9jeVlO8eAGnL9Zo0VYoELjst1fqr9wVCA3BKhDXNpR4drEHQ3u1fCxUUthBWrqn5QYltwZzMrS1cK7gap4BkvKzCeVCeKCWxgb+DLpBmlzNvG+Vmb5iK1BLGj48H58PqiXlE9dWno1tMmiTWWfYLWlcdnOir+JsPryv9apmJri6J3HtlBOUJRBRcjrXGnU3g1dqRgXQCArvQ2pkRKzeuLr2PkpCIs60DRKYdKEOnN5J9ik8lCYFqLgm1Rm24YIR8xK9+1mhYuDsGq+UiEuQVKiSW0qUEVYGbQiDqouLDovuq1IqWqMw+uYh4eBaPKwrmsCFihm4hu0/VOwq8iLl0tJm8dYGFYclEGbZMdNKiDIVySnNLNj73iGRt/sBEJ/cVDE5KhYVj9Fvx6/0jq2YkiwMggr6GtfoOJ0EUW46iwg0VVWcRiHSfQlmvJ6OJXtganMRFQ/n+a5abfCpW/F5TEWqBDkBEFgslEGnYUrfxzSmonsC2dTWq27ixSLhCVqc2Ev7MVWf4xh8wQLpMfRTsFbo5yASA193nFdlPGFHzV9W8XuWNaixIyNwWBoBrD5Sm7HrcgEC4RVk66K2se5GWuf0kVbucNEbXbBFZA7iL6P5YTVU2j4eZnn3deSbErfrQvHWWJ+6e3EjgJQQjS7iuO/8Qy9GMcKh4lqzw0XaWVYrAtD5v6EDrhfJsAyKRaIeSKqi49z6L2guK2U3NwGEoRGKBQWnhY+7pkKXRwMvocLTmAd4IHXFMirSLAyFrMxFxYVJfTjXpF44uQuH4uOOjXkgtywXzO3/uJgDsJCHAVVHK4ibbFkKzA1mL8x1KHd3pGE5eqNAzL5/QGkUpu+NcYCb4KrTqDCn0h1XVQBa2Asya5i0HvndUJHxNPRJ+Hm8VxRm419NLRrWF2r/tpHCbq/Azp1ffkJsnrGrBwWz80cVoNUM1ZBh9WYW/7dEUkgKrpuCJuPKCqq+c1VEfDFS8Cq58srqFIs54dgWGUClbF3ZQB0xsn9cmAfmZTm7zisT96tsOAntiZA9fNFKo81OE8UqEKRpCmKS+235ly4YbIfQzIVjoMtdkd2L+vEWBkEwQnt/WWqBEviO6f5Z7RNz3sogARBYNTcXVe8BVM5qFHRaMt/7eIaFoeH/nK5BCpnqsfTlnKNBW9cWhiqXJqzpcF9vJOGAcFte/gZ/5xdFxZiUXgAYV2cAcrkJo6rIBxjoa8Alb8bnGodSoPTZtelRs21praxU/6J/lnNCGfxEByYKmMlnM9FAT8ojSRgRZ5guYaWbgegRNhQXHp67UQHKiz8YGt16mcPCy2+F088ZTpScuhwbMfnGc6P6fZywZPGoXNYlxiq52lcvBlFFGRWKEP3u3rJ4wUZCAjrQoNF2raA3F6x/+BYI8+T0zCF30MirMbfNVyldJVf6HSQjKeQGvdA60BlxXPpjbHw2jhCa/EDslJ3XyOHhscQB88RV4pVBicHK+NimT6d9xpRfQWUrTRC8j011DIPzyJ5aQEWqZCm3n4exh799SuQQYW1yFxEWODD9De8Harg/ViGClNXEc79Mhhhszo8ExkirB+9uFAtmtV6i4VryIM3i9GNtJeGDKiAYYJ+jjtx4dvxqFcMWHX5XGBYYZEXZiLe74X1T4TCf3oIja/w4TrqMA8zTeMgxjz5sUU0PJz8ljF03tNu27KH1baluGCfBU1oNMLjVXUVCyw/+6MAaywpS4B4uly8kOa4JWMn4DkgQ+0Vo7tYAmtksBOzqFBb3FdVOhxZGTt3FmArrQN0N2R7WXY4/ChFPMEPwsJGf7ccu4414w+ouRZhmfnhAKucbcf5rNOjU2PAKq5dMjuUOGsLVDW5AHdmL1tVhFViUbIIS4XInT2YDo2MwiFPewT7QhVhRZP5zGWu7Ffpe1jwg/LHgQv8V0JxTsQhNAnLfcGMzn2hUqAaAC4yfwj8Zz5ZxZw6YGFJjOsU6i3fXWQo8YODfgMTYx0oMGaTT2LTsq1AtJ6LOYQvBejXNK0v5iyz+Bl5Zd76DBZor8QSvDFLvorKzPYweSw+tTfpCIuONTyev+PitJ42PdluX/ZKrAOKvfQJa/k2Hi4Ql0sj7lxOhPUP3N7xhQ6m9eKxfa2rvYTlLVbwlH/djWA06wIWnnEMWBl9f2f0hQvuDAzd4ysD08tYtLLe7xClsznIxj5PBix8lQJpHXCOENWg8HDEeuMGXAGrfKBefarnNZZdsPCgKtd0gHXQ8Qkz9xo9DI8vZ+JXYzkI9OjkLzgXdaUvd3XC6boqFFGFzR3/oBvO75fXMgGVV+5RsG6VntgTw3aODsWnty5ahQZ5vZcrldY3cOjUw4+N0T5wBEr3h6VaT8n0+G77evFEUhko3PlZlSwNxQqUpfNkoj92o3wn1/NYWfvLf5wfGKywJlFifskOD2IqgsDG7b7ELbFwe8Iv98qJN8G4seHDpG4dZroFemLc7OLcEAtV6AmMy5SA5Q4oQZtKYxoCo9QuaoKCJ7TK9mZvN8Eiw3KSKXxvLlQ4DLT6jgc8LI3i00u2e5+4nsGiAxH0+cAVygrh9wwLu96Vx6hGO2WApd9nXdexTm2jVThXF07I/a8/PaW2pz2w3igYC7e9PgILDyUV4UQSqMudsv13ONQ1b9UEqco/270r1l/DQlktp8oidRXWtfJmZ2qG4nJvqc7v0eIVLKaiz4d/sboKf9Rld/sByjO/W321Bfl9LOmpiGz6EY9G/N93Nie54HBY9jXd85uwSFZhPx5kFakjYO3OGMm4nO7ljbFO7SMe/Vqokjd4IZZ7WHg6wL/xxlhIZSfzlzOhH+nHT3xeqd7HQml9DNaxfdR8dgTB+pRK4u4hnSoxu+pH2/JnMW6KJdszUtHOd236h/WzpaGnQMd7LY6MsG5o8vJIVP4I5+aAHGPh+qL2pIEBwhjcura3DBBIVYcTnGJzbA/jpT9Z8n/bMI6TDKBCLHXDcHoCqimcw909IJe5p3uzk4zD+S8z2XeVEMlBKZQV78j3TLXNau5gAnLp81aWTeF0bOy7uusYC6jUMi3bP0wIZfQ08fDKVCvrwpGwdSoG07pNvYWH6Baq/soRR1huojb1Ssff6cON6EJ5u1Q3KgNXVFAO007uxny++eMl8Brd4REceaJ9X3iq0Mw79e8UVqzEsxIx1bUl2+Vlajwvx8POVbityTTvm9wsWOeCzjC40zF42KJYVpXnOfyHTi/BuoKmzTh+f2xOsnn8Po4mzHKf2Vd9E5YEs5jdrJ/HsMt3GsKReYzcx1P7/4saAWzS9KUP+nKUX1hif3v+c1+H1Wa1iNe8v3gfF9RIR71IsDSCx/2LZexdT6/YxX0l1uRRxJWFCL1zsEx84T+xylnziwG8cGbhLVgmlZA7xyNEgjlDaOc9KzEJ2kDhQ8WiD+i9mX69f1C5YPUblYmV9PBcFpboFEVLPDDWi/XqzctnFt6Edc2eAhf/ogu3F9H0NVrUgoxrun56+tZYK0ZdSLb7rJymWMQCbH3nMOE7sfqra5qm+FdrmkzytxsaEZ6DB6L879vMmSOswwvrV/TYHRvD0JQ1ZYnaK8vm0Lbt7mGsd2D91pLrvZUbQcUj3SyTWZb+lPx4vZLJlR8Fn941z1qv/wDh+9gFH+DPKgAAAABJRU5ErkJggg=="  # logo 2bProud (PNG com transparência) para a capa
LOGO_SRC = ""
DPI = int(os.getenv("DPI_GRAFICOS", "160"))  # 160 cabe em 512 MB; 200 = nitidez máxima

# ----------------------------------------------------------------- cores
CAPA_BG = "#1C1C1C"
CINZA = "#8B9096"
PRETO = "#1C1C1C"
VERDE = "#2B6940"
VERMELHO = "#963433"
MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho",
         "agosto", "setembro", "outubro", "novembro", "dezembro"]
ROMANOS = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]


# ----------------------------------------------------------------- formatação
def brl(v, sinal=False):
    """R$ 1.234,56 ; negativos como -R$ 1.234,56"""
    s = f"{abs(v):,.2f}".replace(",", "@").replace(".", ",").replace("@", ".")
    if v < 0:
        return f"-R$ {s}"
    return f"+R$ {s}" if sinal and v > 0 else f"R$ {s}"


def md(texto):
    """**negrito** e *itálico* -> HTML, com escape do resto."""
    t = html.escape(texto, quote=False)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"<i>\1</i>", t)
    return t


def paras(lista):
    if isinstance(lista, str):
        lista = [lista]
    return "".join(f"<p>{md(p)}</p>" for p in (lista or []))


def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]+", "", s.title())


# ----------------------------------------------------------------- gráficos (padrão 2bProud)
def _fmt(fmt, v):
    t = fmt.format(v)
    if "R$" in fmt or "%" in fmt:
        t = t.replace(",", "@").replace(".", ",").replace("@", ".")
    return t.replace("$", r"\$")


def _eixos(ax):
    for lado in ("top", "right", "left"):
        ax.spines[lado].set_visible(False)
    ax.spines["bottom"].set_color("#BBBBBB")
    ax.yaxis.grid(True, linestyle="--", linewidth=0.8, color="#DDDDDD", zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(axis="both", length=0, labelsize=13, colors="#4D4D4D")


def _titulo(fig, titulo, subtitulo):
    titulo, subtitulo = titulo.replace("$", r"\$"), subtitulo.replace("$", r"\$")
    fig.text(0.045, 0.94, titulo, fontsize=22, fontweight="bold", color="#1A1A1A")
    fig.add_artist(plt.Line2D([0.045, 0.985], [0.855, 0.855], color="#C9C9C9", linewidth=1.2,
                              transform=fig.transFigure))
    fig.text(0.045, 0.775, subtitulo, fontsize=12.5, color="#7A7A7A")


def g_agrupado(path, titulo, subtitulo, categorias, series, fmt="{:.0f}", figsize=(11, 6.2), legenda=None):
    """series: [{label, values, color (str ou lista), label_colors (opcional)}]"""
    fig = plt.figure(figsize=figsize, dpi=DPI)
    ax = fig.add_axes([0.06, 0.10, 0.90, 0.60])
    n = len(series)
    w = 0.72 / n
    x = np.arange(len(categorias))
    for i, s in enumerate(series):
        off = (i - (n - 1) / 2) * w
        bars = ax.bar(x + off, s["values"], width=w * 0.92, color=s["color"], zorder=3, label=s["label"])
        lcs = s.get("label_colors") or ["#1A1A1A"] * len(s["values"])
        for b, v, lc in zip(bars, s["values"], lcs):
            ax.annotate(_fmt(fmt, v), (b.get_x() + b.get_width() / 2, b.get_height()), ha="center",
                        va="bottom", fontsize=13, fontweight="bold", color=lc, xytext=(0, 4),
                        textcoords="offset points")
    ax.set_xticks(x)
    ax.set_xticklabels(categorias, fontsize=13.5, color="#333333")
    _eixos(ax)
    ax.set_ylim(0, max(max(s["values"]) for s in series) * 1.15 or 1)
    handles = legenda or None
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.045, 0.735), frameon=False,
               fontsize=13.5, ncol=len(handles) if handles else n, handlelength=1.1, handleheight=1.1,
               columnspacing=1.4)
    _titulo(fig, titulo, subtitulo)
    fig.savefig(path, facecolor="white")
    plt.close(fig)


def g_barras(path, titulo, subtitulo, rotulos, valores, cores, fmt="{:.0f}", figsize=(9.5, 6.2), largura=0.5):
    fig = plt.figure(figsize=figsize, dpi=DPI)
    ax = fig.add_axes([0.09, 0.10, 0.85, 0.58])
    bars = ax.bar(rotulos, valores, color=cores, width=largura, zorder=3)
    for b, v in zip(bars, valores):
        ax.annotate(_fmt(fmt, v), (b.get_x() + b.get_width() / 2, b.get_height()), ha="center", va="bottom",
                    fontsize=15, fontweight="bold", color="#1A1A1A", xytext=(0, 5), textcoords="offset points")
    _eixos(ax)
    ax.set_xticks(range(len(rotulos)))
    ax.set_xticklabels(rotulos, fontsize=12.5 if len(rotulos) > 3 else 13.5, color="#333333")
    ax.set_ylim(0, max(valores) * 1.15 or 1)
    _titulo(fig, titulo, subtitulo)
    fig.savefig(path, facecolor="white")
    plt.close(fig)


def quebra(nome, largura=16):
    """quebra rótulos longos em até 3 linhas para o eixo x"""
    palavras, linhas, atual = nome.split(), [], ""
    for p in palavras:
        if len(atual) + len(p) + 1 > largura and atual:
            linhas.append(atual)
            atual = p
        else:
            atual = (atual + " " + p).strip()
    linhas.append(atual)
    return "\n".join(linhas[:3])


# ----------------------------------------------------------------- blocos HTML
def h1(titulo, numeral=None):
    n = f'<span class="num">{numeral}.</span> ' if numeral else ""
    return f'<h1>{n}{html.escape(titulo.upper())}</h1>'


def kpis(lista):
    cel = "".join(f'<div class="kpi"><span>{html.escape(k["rotulo"].upper())}</span>'
                  f'<b>{md(k["valor"])}</b></div>' for k in lista)
    return f'<div class="kpis">{cel}</div>'


def figura(arq, largura="100%"):
    return f'<figure><img src="{arq}" style="width:{largura}"></figure>'


# ----------------------------------------------------------------- montagem
def montar(d, build):
    loja = d["loja"]
    mes = d["mes"].strip().lower()
    ano = d["ano"]
    mes_cap = mes.capitalize()
    rot_atual = d.get("rotulo_atual") or f"{mes_cap}/{ano}"
    per_curto = d.get("rotulo_periodo") or mes
    per_longo = d.get("rotulo_periodo") or f"{mes}/{ano}"
    loja_rodape = f'{loja["nome"]} — {loja["cidade"]} ({loja["uf"]})'
    s = d["secoes"]
    corpo = []
    num = iter(ROMANOS)

    # nota de confidencialidade (fixa)
    entidade = d.get("entidade_confidencialidade") or f'do {loja["nome"]}'
    corpo.append(f'''<div class="conf"><span class="eyebrow">NOTA DE CONFIDENCIALIDADE</span>
      <h2 class="conf-t">Uso restrito e confidencial</h2>
      <p>As informações contidas neste relatório são de natureza estritamente confidencial e estratégica, de uso
      exclusivo da diretoria e dos consultores autorizados da 2bProud Consultoria e {html.escape(entidade)}. O
      compartilhamento, a distribuição ou a reprodução parcial ou total deste documento a terceiros não
      autorizados é expressamente proibido.</p></div>''')

    # sumário executivo + destaques (obrigatórios)
    corpo.append(h1("Sumário executivo"))
    corpo.append(paras(d["sumario"]))
    if d.get("destaques"):
        corpo.append(f'<h2>{html.escape(d.get("destaques_titulo", "Destaques do mês"))}</h2><ul class="dash">' +
                     "".join(f"<li>{md(x)}</li>" for x in d["destaques"]) + "</ul>")

    if s.get("sobre"):
        corpo.append(h1("Sobre este relatório", next(num)))
        corpo.append(paras(s["sobre"]))

    f = s.get("financeiro")
    if f:
        corpo.append(h1("Resultado financeiro", next(num)))
        com_margem = bool(f.get("margem"))
        mg = lambda m: (m["liquido"] / m["vendas"] * 100) if m["vendas"] else 0
        pct = lambda v: f"{v:.1f}%".replace(".", ",")
        linhas = "".join(
            f'<tr><td class="l">{html.escape(m["mes"])}</td><td>{brl(m["vendas"])}</td><td>{brl(-abs(m["taxas"]))}</td>'
            f'<td>{brl(-abs(m["promocoes"]))}</td><td>{brl(m.get("ajustes", 0))}</td><td>{brl(m["liquido"])}</td>'
            + (f'<td>{pct(mg(m))}</td>' if com_margem else "") + '</tr>'
            for m in f["meses"])
        corpo.append('<table class="dados"><thead><tr><th class="l">MÊS</th><th>VALOR DE<br>VENDAS</th>'
                     '<th>TAXAS/<br>COMISSÕES</th><th>SERVIÇOS E<br>PROMOÇÕES</th><th>AJUSTES</th>'
                     f'<th>FATURAMENTO<br>LÍQUIDO</th>' + ('<th>MARGEM APÓS<br>iFOOD</th>' if com_margem else "") +
                     f'</tr></thead><tbody>{linhas}</tbody></table>')
        g_agrupado(build / "g_financeiro.png", "Evolução Financeira Mensal",
                   "Valor de vendas e faturamento líquido (R$) por mês",
                   [m["mes"] for m in f["meses"]],
                   [{"label": "Valor de vendas", "values": [m["vendas"] for m in f["meses"]], "color": CINZA},
                    {"label": "Faturamento líquido", "values": [m["liquido"] for m in f["meses"]], "color": PRETO}],
                   fmt="R$ {:.0f}")
        corpo.append(figura("g_financeiro.png"))
        corpo.append(paras(f.get("texto")))

        # margem após iFood (opcional): evolução, com o ponto de partida (ex.: mesmo mês do ano anterior)
        yoy = f.get("yoy")
        if com_margem:
            pontos = ([(yoy["rotulo_anterior"], mg(yoy["anterior"]))] if yoy else []) + \
                     [(m["mes"], mg(m)) for m in f["meses"]]
            g_barras(build / "g_margem.png", "Margem após iFood",
                     "Faturamento líquido como % do valor de vendas (antes do custo dos produtos)",
                     [p[0] for p in pontos], [p[1] for p in pontos],
                     [CINZA] * (len(pontos) - 1) + [PRETO], fmt="{:.1f}%", figsize=(10.5, 6.2), largura=0.55)
            corpo.append(figura("g_margem.png", "80%"))
            corpo.append(paras(f.get("texto_margem")))

        # comparativo ano contra ano (opcional)
        if yoy:
            a, b = yoy["anterior"], yoy["atual"]
            ra, rb = yoy["rotulo_anterior"], yoy["rotulo_atual"]
            def var(x, y):
                return "—" if not x else f"{(y / x - 1) * 100:+.1f}%".replace(".", ",")
            def linha(nome, x, y, neg=False):
                sx, sy = (-abs(x), -abs(y)) if neg else (x, y)
                return f'<tr><td class="l">{nome}</td><td>{brl(sx)}</td><td>{brl(sy)}</td><td>{var(x, y)}</td></tr>'
            dm = mg(b) - mg(a)
            tab = (linha("Valor de vendas", a["vendas"], b["vendas"]) +
                   linha("Taxas e comissões", a["taxas"], b["taxas"], True) +
                   linha("Serviços e promoções", a["promocoes"], b["promocoes"], True) +
                   f'<tr><td class="l">Ajustes</td><td>{brl(a.get("ajustes", 0))}</td><td>{brl(b.get("ajustes", 0))}</td><td>—</td></tr>' +
                   linha("Faturamento líquido", a["liquido"], b["liquido"]) +
                   f'<tr><td class="l">Margem após iFood</td><td>{pct(mg(a))}</td><td>{pct(mg(b))}</td>'
                   f'<td>{dm:+.1f} p.p.'.replace(".", ",") + '</td></tr>')
            corpo.append(f'<h2>{html.escape(yoy.get("titulo", "Comparativo ano contra ano"))}</h2>')
            corpo.append(f'<table class="dados"><thead><tr><th class="l">INDICADOR</th><th>{html.escape(ra.upper())}</th>'
                         f'<th>{html.escape(rb.upper())}</th><th>VARIAÇÃO</th></tr></thead><tbody>{tab}</tbody></table>')
            if yoy.get("grafico", True):
              g_agrupado(build / "g_yoy.png", "Comparativo Ano contra Ano",
                         f"Valor de vendas e faturamento líquido (R$) — {ra} vs. {rb}",
                         [ra, rb],
                         [{"label": "Valor de vendas", "values": [a["vendas"], b["vendas"]], "color": CINZA},
                          {"label": "Faturamento líquido", "values": [a["liquido"], b["liquido"]], "color": PRETO}],
                         fmt="R$ {:,.0f}", figsize=(10.5, 6.2))
            if yoy.get("grafico", True):
              corpo.append(figura("g_yoy.png", "88%"))
            corpo.append(paras(yoy.get("texto")))

    inc = s.get("incentivos")
    if inc:
        corpo.append(h1("Investimento em incentivos e mídia", next(num)))
        corpo.append(kpis(inc["kpis"]))
        r = inc.get("retorno")
        if r:
            g_barras(build / "g_retorno.png", "Retorno Geral por Real Investido",
                     "R$ de vendas gerado por R$ investido em incentivos — evolução mensal",
                     [r.get("rotulo_anterior", "Período anterior"), r.get("rotulo_atual", rot_atual)],
                     [r["anterior"], r["atual"]], [CINZA, PRETO], fmt="R$ {:.2f}")
            corpo.append(figura("g_retorno.png", "64%"))
        corpo.append(paras(inc.get("texto_retorno")))
        iv = inc.get("investimento")
        if iv:
            total = iv["loja"] + iv["ifood"]
            g_barras(build / "g_investimento.png", "Investimento em Incentivos",
                     f"Divisão do investimento total ({brl(total)}) entre loja e iFood — {per_longo}",
                     ["Minha loja", "iFood"], [iv["loja"], iv["ifood"]], [PRETO, CINZA], fmt="R$ {:,.2f}")
            corpo.append(figura("g_investimento.png", "64%"))
        corpo.append(paras(inc.get("texto_investimento")))

    fu = s.get("funil")
    if fu:
        corpo.append(h1("Conversão do cardápio", next(num)))
        etapas = fu.get("etapas") or ["Visitas", "Visualizações\nde cardápio", "Itens na\nsacola",
                                      "Pedidos\nrevisados", "Pedidos\nconcluídos"]
        g_agrupado(build / "g_funil.png", "Funil de Conversão da Loja",
                   f"Etapas da jornada do cliente até o pedido concluído — {per_curto} vs. período anterior",
                   etapas,
                   ([{"label": "Período anterior", "values": fu["anterior"], "color": CINZA}] if fu.get("anterior") else []) +
                   [{"label": rot_atual, "values": fu["atual"], "color": PRETO}])
        corpo.append(figura("g_funil.png"))
        corpo.append(paras(fu.get("texto")))

    cl = s.get("clientes")
    if cl:
        corpo.append(h1("Perfil de clientes", next(num)))
        cats = ["Clientes\nnovos", "Clientes\nfrequentes", "Clientes\nem alerta", "Clientes\nsumidos",
                "Clientes\nrecuperados"]
        # subir é bom para novos, frequentes e recuperados; ruim para alerta e sumidos
        bom_subir = [True, True, False, False, True]
        cores, lcs = [], []
        for a, b, bs in zip(cl["anterior"], cl["atual"], bom_subir):
            bom = (b >= a) if bs else (b <= a)
            if b == a:
                cores.append(CINZA); lcs.append("#1A1A1A")
            else:
                cores.append(VERDE if bom else VERMELHO); lcs.append(VERDE if bom else VERMELHO)
        leg = [Patch(color=CINZA, label="Período anterior"), Patch(color=VERDE, label="Resultado positivo"),
               Patch(color=VERMELHO, label="Resultado negativo")]
        g_agrupado(build / "g_clientes.png", "Perfil de Clientes",
                   f'Clientes organizados por hábito de pedido — comparação {cl["data_inicio"]} vs. {cl["data_fim"]}',
                   cats,
                   [{"label": "Período anterior", "values": cl["anterior"], "color": CINZA},
                    {"label": rot_atual, "values": cl["atual"], "color": cores, "label_colors": lcs}],
                   figsize=(11.5, 6.4), legenda=leg)
        corpo.append(figura("g_clientes.png"))
        corpo.append(paras(cl.get("texto")))

    op = s.get("operacao")
    if op:
        corpo.append(h1("Qualidade da operação", next(num)))
        corpo.append(kpis(op["kpis"]))
        corpo.append(paras(op.get("texto")))

    it = s.get("itens")
    if it:
        corpo.append(h1("Itens mais vendidos", next(num)))
        nomes = [quebra(n) for n in it["nomes"]]
        g_barras(build / "g_itens.png", "Itens Mais Vendidos do Cardápio",
                 it.get("subtitulo", f"Quantidade vendida por item no período — top {len(nomes)} por volume"),
                 nomes, it["valores"], [PRETO] + [CINZA] * (len(nomes) - 1),
                 fmt=it.get("formato", "{:.0f}"), figsize=(11, 6.6), largura=0.62)
        corpo.append(figura("g_itens.png"))
        corpo.append(paras(it.get("texto")))

    vc = s.get("venda_cruzada")
    if vc:
        corpo.append(h1("Venda cruzada (complementos)", next(num)))
        if vc.get("kpis"):
            corpo.append(kpis(vc["kpis"]))
        cp = vc.get("comparativo")
        if cp:
            g_barras(build / "g_vc_comp.png", "Venda Cruzada no Faturamento",
                     cp.get("subtitulo", "Complementos pagos como % do valor de vendas"),
                     cp["rotulos"], cp["valores"], [CINZA] * (len(cp["valores"]) - 1) + [PRETO],
                     fmt="{:.1f}%", figsize=(9.5, 6.2))
            corpo.append(figura("g_vc_comp.png", "64%"))
        corpo.append(paras(vc.get("texto")))
        tp = vc.get("top")
        if tp:
            nomes = [quebra(n, 12) for n in tp["nomes"]]
            g_barras(build / "g_vc_top.png", "Complementos que Mais Faturaram",
                     tp.get("subtitulo", "Valor vendido por complemento no período (R$)"),
                     nomes, tp["valores"], [PRETO] + [CINZA] * (len(nomes) - 1),
                     fmt="R$ {:,.0f}", figsize=(11, 6.4), largura=0.62)
            corpo.append(figura("g_vc_top.png"))
            corpo.append(paras(tp.get("texto")))

    ac = s.get("acoes")
    if ac:
        corpo.append(h1("Ações recomendadas e próximos passos", next(num)))
        for a in ac:
            corpo.append(f'<h2>{html.escape(a["titulo"])}</h2>' + paras(a["texto"]))

    if d.get("cta"):
        corpo.append('<div class="conf" style="margin-top:14pt"><span class="eyebrow">PRÓXIMO PASSO</span>' + paras(d["cta"]) + "</div>")
    if d.get("aviso"):
        corpo.append('<p style="font-size:8.5pt;color:#6b6b6b">' + md(d["aviso"]) + "</p>")
    c = d.get("contato", {})
    corpo.append(f'''<div class="fim"><b>{html.escape(c.get("empresa", "2bProud Consultoria"))}</b>
      <span>{html.escape(c.get("telefone", "(21) 97949-8333"))}</span>
      <span>{html.escape(c.get("instagram", "@2b.proud"))}</span></div>''')

    titulo = d.get("titulo_capa") or f"FECHAMENTO DE {mes.upper()}"
    capa = f'''<div class="capa">
      <img class="logo" src="{LOGO_SRC}">
      <div class="marca">2bPROUD</div><div class="cons">CONSULTORIA</div>
      <div class="titulo">{html.escape(titulo)}</div>
      <div class="sub">{html.escape(d.get("subtitulo_capa", "RELATÓRIO DE RESULTADOS MENSAIS"))}</div>
      <div class="loja">{html.escape(loja["nome"].upper())}</div>
      <div class="loc">{html.escape(loja["cidade"])} ({html.escape(loja["uf"])})  ·  ID {html.escape(str(loja["id"]))}</div>
      <div class="confid"><span>DOCUMENTO CONFIDENCIAL</span></div>
      <div class="elab">Elaborado por 2bProud Consultoria</div></div>'''
    return capa, "\n".join(corpo), loja_rodape


CSS = """
@page{size:Letter;margin:0.9in 1.1in 0.8in 1.1in}
*{box-sizing:border-box}
html,body{margin:0}
body{font-family:Carlito,Calibri,Lato,"DejaVu Sans",sans-serif;font-size:10.5pt;color:#262626;line-height:1.42;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
p{margin:0 0 7pt;text-align:justify;hyphens:manual}
b{color:#111}
h1{font-size:12.5pt;font-weight:700;color:#111;margin:16pt 0 9pt;padding-bottom:4pt;border-bottom:1.3px solid #222;
  break-after:avoid;letter-spacing:.1pt}
h1 .num{color:#9E9E9E}
h2{font-size:10.5pt;font-weight:700;color:#111;margin:11pt 0 5pt;break-after:avoid}
.eyebrow{display:block;font-size:8pt;font-weight:700;color:#6b6b6b;letter-spacing:.6pt}
.conf{background:#F2F2F2;border:1px solid #555;padding:10pt 13pt 9pt;margin:0 0 4pt;break-inside:avoid}
.conf .conf-t{font-size:15pt;margin:3pt 0 4pt}
.conf p{font-size:9.3pt;color:#3d3d3d;text-align:left;margin:0;line-height:1.38}
ul.dash{list-style:none;margin:0 0 6pt;padding:0 0 0 .22in}
ul.dash li{padding-left:2.1em;text-indent:-1.15em;margin:0 0 4pt;line-height:1.38}
ul.dash li::before{content:"— ";font-weight:700}
table.dados{width:100%;border-collapse:collapse;font-size:9.6pt;margin:4pt 0 8pt}
table.dados th{background:#1C1C1C;color:#fff;font-size:8.3pt;font-weight:700;padding:6pt 5pt;border:1px solid #333;
  text-align:center;line-height:1.25}
table.dados td{padding:5pt 5pt;border:1px solid #D9D9D9;text-align:center}
table.dados .l{text-align:left;font-weight:700;padding-left:9pt}
table.dados tr{break-inside:avoid}
figure{margin:4pt 0 6pt;text-align:center;break-inside:avoid}
figure img{display:inline-block}
.kpis{display:grid;grid-template-columns:1fr 1fr;gap:9pt 10pt;margin:6pt 4pt 10pt;break-inside:avoid}
.kpi{border:1px solid #C9C9C9;background:#FAFAFA;padding:9pt 11pt 8pt;display:grid;gap:3pt}
.kpi span{font-size:7.8pt;font-weight:700;color:#6b6b6b;letter-spacing:.5pt}
.kpi b{font-size:13pt;color:#111}
.fim{border-top:1px solid #BDBDBD;margin-top:8pt;padding-top:16pt;text-align:center;display:grid;gap:2pt;break-inside:avoid}
.fim b{font-size:10.5pt;letter-spacing:.6pt}
.fim span{font-size:9pt;color:#6b6b6b}
.pular{break-after:page;height:1px}
"""

CSS_CAPA = """
@page{size:Letter;margin:0}
html,body{margin:0}
body{-webkit-print-color-adjust:exact;print-color-adjust:exact;font-family:Carlito,Calibri,Lato,"DejaVu Sans",sans-serif}
.capa{width:8.5in;height:11in;background:#1C1C1C;color:#fff;text-align:center;position:relative;overflow:hidden}
.capa>*{position:absolute;left:0;width:100%;transform:translateY(-50%);white-space:nowrap}
.logo{top:3.565in;left:50%!important;width:0.78in!important;transform:translate(-50%,-50%)!important}
.marca{top:4.33in;font-size:13.3pt;font-weight:700;letter-spacing:3.1pt}
.cons{top:4.535in;font-size:7.7pt;letter-spacing:3.9pt;color:#A9A9A9}
.titulo{top:5.43in;font-size:22.2pt;font-weight:700}
.sub{top:5.87in;font-size:12.8pt;font-weight:700;color:#ADB1B8;letter-spacing:.8pt}
.loja{top:6.41in;font-size:11.2pt;font-weight:700}
.loc{top:6.63in;font-size:10.1pt;color:#ADADAD}
.confid{top:7.76in}
.confid span{background:#C9CED4;color:#1C1C1C;font-size:8.9pt;font-weight:700;letter-spacing:1.3pt;padding:1pt 2pt}
.elab{top:9.04in;font-size:9.1pt;color:#A6A6A6}
"""


def pdf(capa, corpo, rodape, saida, build):
    from playwright.sync_api import sync_playwright
    (build / "capa.html").write_text(f"<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'>"
                                     f"<style>{CSS_CAPA}</style></head><body>{capa}</body></html>", encoding="utf-8")
    # página em branco no início: o rodapé começa em "Página 2"; ela é trocada pela capa depois
    (build / "corpo.html").write_text(f"<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'>"
                                      f"<style>{CSS}</style></head><body><div class='pular'></div>{corpo}</body></html>",
                                      encoding="utf-8")
    fonte = "font-family:Carlito,Calibri,Lato,'DejaVu Sans',sans-serif"
    head = (f"<div style=\"{fonte};width:100%;margin:0 1.1in;font-size:7.3pt;color:#7b7b7b;font-weight:700;"
            f"letter-spacing:.8pt;display:flex;justify-content:space-between;border-bottom:.6px solid #D9D9D9;"
            f"padding:0 0 3pt;margin-top:.5in\"><span>2bPROUD CONSULTORIA</span><span>CONFIDENCIAL</span></div>")
    foot = (f"<div style=\"{fonte};width:100%;text-align:center;font-size:7.6pt;color:#8C8C8C;margin-bottom:.32in\">"
            f"{html.escape(rodape)}  |  Página <b style='color:#333;font-size:9pt'><span class='pageNumber'></span></b></div>")
    with sync_playwright() as p:
        # modo econômico: cabe em servidores de 512 MB (plano grátis/Starter do Render)
        b = p.chromium.launch(args=["--single-process", "--no-zygote", "--disable-dev-shm-usage", "--disable-gpu",
                                    "--disable-extensions", "--js-flags=--max-old-space-size=128"])
        pg = b.new_page()
        pg.goto((build / "capa.html").as_uri()); pg.wait_for_load_state("networkidle")
        pg.pdf(path=str(build / "capa.pdf"), format="Letter", print_background=True, prefer_css_page_size=True)
        pg.goto((build / "corpo.html").as_uri()); pg.wait_for_load_state("networkidle")
        pg.pdf(path=str(build / "corpo.pdf"), format="Letter", print_background=True, prefer_css_page_size=True,
               display_header_footer=True, header_template=head, footer_template=foot)
        b.close()
    if shutil.which("qpdf"):
        subprocess.run(["qpdf", "--empty", "--pages", str(build / "capa.pdf"), "1", str(build / "corpo.pdf"), "2-z",
                        "--", str(saida)], check=True)
    else:
        subprocess.run(["pdfseparate", str(build / "corpo.pdf"), str(build / "c-%03d.pdf")], check=True)
        partes = sorted(build.glob("c-*.pdf"))[1:]
        subprocess.run(["pdfunite", str(build / "capa.pdf"), *map(str, partes), str(saida)], check=True)


def carregar_logo(caminho=None):
    """Logo da capa. Ordem: --logo <arquivo>; logo embutido (validado); logo_2bproud.png na pasta atual."""
    import base64, io
    from PIL import Image
    def valido(dados):
        try:
            Image.open(io.BytesIO(dados)).load()
            return True
        except Exception:
            return False
    candidatos = []
    if caminho:
        candidatos.append(pathlib.Path(caminho).read_bytes())
    try:
        candidatos.append(base64.b64decode(LOGO_B64))
    except Exception:
        pass
    if pathlib.Path("logo_2bproud.png").exists():
        candidatos.append(pathlib.Path("logo_2bproud.png").read_bytes())
    for dados in candidatos:
        if valido(dados):
            fmt = Image.open(io.BytesIO(dados)).format.lower()
            return f"data:image/{'jpeg' if fmt == 'jpeg' else fmt};base64," + base64.b64encode(dados).decode()
    raise RuntimeError("Logo da capa indisponível: passe --logo <arquivo> (PNG do logo 2bProud) ou extraia de um "
             "fechamento antigo com: pdfimages -png -f 1 -l 1 antigo.pdf logo")


def main():
    args = [a for a in sys.argv[1:]]
    logo = None
    if "--logo" in args:
        i = args.index("--logo"); logo = args[i + 1]; del args[i:i + 2]
    dados = json.loads(pathlib.Path(args[0]).read_text(encoding="utf-8"))
    pasta = pathlib.Path(args[1] if len(args) > 1 else ".").resolve()
    global LOGO_SRC
    LOGO_SRC = carregar_logo(logo)
    nome = f'Fechamento_{dados["mes"].strip().capitalize()}_{slug(dados["loja"]["nome"])}_2bProud'
    build = pasta / f"_build_{nome}"
    build.mkdir(parents=True, exist_ok=True)
    capa, corpo, rodape = montar(dados, build)
    saida = pasta / f"{nome}.pdf"
    pdf(capa, corpo, rodape, saida, build)
    print(saida)


if __name__ == "__main__":
    main()
