"""Leitura determinística dos relatórios do Portal do Parceiro cujo formato conhecemos.
O que for lido aqui tem prioridade sobre a leitura da IA (conta feita por código)."""
import re

from .ingest import Arquivo, norm


def num(v) -> float | None:
    if v is None:
        return None
    s = str(v).strip().replace("R$", "").replace("%", "").replace(" ", "")
    if not s or s in ("-", "—"):
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _tem(a: Arquivo, *cols) -> bool:
    cab = {norm(re.sub(r"\.\d+$", "", c)) for c in a.cabecalho}
    return all(norm(c) in cab for c in cols)


def _c(a: Arquivo, nome: str, n=0) -> str | None:
    alvo = norm(nome)
    achados = [c for c in a.cabecalho if norm(re.sub(r"\.\d+$", "", c)) == alvo]
    return achados[n] if len(achados) > n else None


def vendas(arqs) -> dict | None:
    for a in arqs:
        if a.tipo == "texto" and _tem(a, "Logística", "Total de vendas (pedidos)", "Valor total de vendas"):
            cl, cp, cv = _c(a, "Logística"), _c(a, "Total de vendas (pedidos)"), _c(a, "Valor total de vendas")
            cn = _c(a, "Novos clientes")
            por = {}
            novos = 0
            for l in a.linhas:
                k = l.get(cl, "").strip() or "Outros"
                p, v = num(l.get(cp)) or 0, num(l.get(cv)) or 0
                d = por.setdefault(k, {"logistica": k, "pedidos": 0, "valor": 0.0})
                d["pedidos"] += int(p)
                d["valor"] += v
                novos += int(num(l.get(cn)) or 0) if cn else 0
            ped = sum(d["pedidos"] for d in por.values())
            val = sum(d["valor"] for d in por.values())
            return {"pedidos": ped, "valor": round(val, 2), "ticket": round(val / ped, 2) if ped else 0,
                    "novos_clientes": novos, "por_logistica": sorted(por.values(), key=lambda d: -d["pedidos"])}
    return None


DIAS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]


def dias(arqs) -> list | None:
    for a in arqs:
        if a.tipo == "texto" and _tem(a, "Dias", "Total de Vendas (pedidos)"):
            cd, cp = _c(a, "Dias"), _c(a, "Total de Vendas (pedidos)")
            tot = {d: 0 for d in DIAS}
            for l in a.linhas:
                k = next((d for d in DIAS if norm(d) == norm(l.get(cd, ""))), None)
                if k:
                    tot[k] += int(num(l.get(cp)) or 0)
            return [{"dia": d, "pedidos": tot[d]} for d in DIAS]
    return None


def horarios(arqs) -> list | None:
    for a in arqs:
        if a.tipo == "texto" and _tem(a, "Horário", "Total de Vendas (pedidos)"):
            ch, cp = _c(a, "Horário"), _c(a, "Total de Vendas (pedidos)")
            tot = {}
            for l in a.linhas:
                k = l.get(ch, "").strip()
                if k:
                    tot[k] = tot.get(k, 0) + int(num(l.get(cp)) or 0)
            ordem = sorted(tot, key=lambda k: int((re.findall(r"\d+", k) or ["0"])[0]))
            return [{"faixa": k, "pedidos": tot[k]} for k in ordem]
    return None


def itens(arqs) -> list | None:
    for a in arqs:
        if a.tipo == "texto" and _tem(a, "Nome do item", "Vendas total (quantidade)", "Valor Total"):
            cn, cq, cv = _c(a, "Nome do item"), _c(a, "Vendas total (quantidade)"), _c(a, "Valor Total")
            cvis, cped, cpr = _c(a, "Visitas"), _c(a, "Pedidos"), _c(a, "Vendas total com promoção")
            out = []
            for l in a.linhas:
                nome = l.get(cn, "").strip()
                if not nome:
                    continue
                out.append({"nome": nome, "quantidade": int(num(l.get(cq)) or 0),
                            "valor_total": round(num(l.get(cv)) or 0, 2),
                            "visitas": int(num(l.get(cvis)) or 0) if cvis else None,
                            "pedidos": int(num(l.get(cped)) or 0) if cped else None,
                            "qtd_com_promocao": int(num(l.get(cpr)) or 0) if cpr else None})
            return sorted(out, key=lambda d: -d["quantidade"])
    return None


def ler_conhecidos(arqs) -> dict:
    return {"vendas": vendas(arqs), "dias": dias(arqs), "horarios": horarios(arqs), "itens": itens(arqs)}
