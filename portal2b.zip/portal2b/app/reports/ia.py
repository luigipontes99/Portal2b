"""Chamadas ao Claude: (1) transcrever prints/planilhas em JSON e (2) redigir os textos neutros.
Nada é salvo: os arquivos vão na requisição e a resposta volta para a memória do processo."""
import base64, json, pathlib

from .. import config

PROMPTS = pathlib.Path(__file__).resolve().parent.parent / "prompts"

_n = {"type": ["number", "null"]}
_i = {"type": ["integer", "null"]}
_s = {"type": ["string", "null"]}
_etapas = {"type": "object", "properties": {k: _i for k in ("visitas", "visualizacoes", "sacola", "revisao", "concluidos")}}
_cli = {"type": "object", "properties": {k: _i for k in ("novos", "frequentes", "em_alerta", "sumidos", "recuperados")}}
_promo = {"type": "object", "properties": {
    "investimento_loja": _n, "investimento_ifood": _n, "retorno": _n, "classificacao": _s,
    "pedidos_com_promocao": _i, "pedidos_mais_de_uma": _i, "vendas_com_promocao": _n, "ticket": _n}}

SCHEMA_EXTRACAO = {
    "type": "object",
    "properties": {
        "loja": {"type": "object", "properties": {"nome": _s, "id": _s, "cidade": _s, "uf": _s}},
        "financeiro_meses": {"type": "array", "items": {"type": "object", "properties": {
            "mes": _i, "ano": _i, "vendas": _n, "taxas": _n, "promocoes": _n, "ajustes": _n, "liquido": _n},
            "required": ["mes", "ano"]}},
        "funil": {"type": "object", "properties": {
            "atual": _etapas, "anterior": _etapas,
            "concorrencia": {"type": "object", "properties": {
                "conversao_pct": _n, "visitas_vs_loja_pct": _n, "visita_para_visualizacao_pct": _n}}}},
        "promocoes": {"type": "object", "properties": {"atual": _promo, "anterior": _promo}},
        "clientes": {"type": "object", "properties": {"data_anterior": _s, "data_atual": _s,
                                                       "anterior": _cli, "atual": _cli}},
        "anuncios": {"type": "object", "properties": {
            "investimento": _n, "pedidos": _i, "vendas": _n, "visitas": _i, "custo_por_pedido": _n,
            "novos_clientes": _i, "retorno": _n}},
        "operacao": {"type": "object", "properties": {
            "nivel_super": _s, "projecao_super": _s, "media_avaliacoes": _n, "qtd_avaliacoes": _i,
            "tempo_online_pct": _n, "chamados_respondidos_pct": _n, "cancelamentos_qtd": _i,
            "cancelamentos_valor": _n, "cancelamentos_impacto_super": _i, "negociacoes": _i,
            "entregas_no_prazo_pct": _n, "tempo_preparo_min": _n}},
        "complementos_pagos": {"type": "object", "properties": {"valor_total": _n, "quantidade": _i}},
        "avisos": {"type": "array", "items": {"type": "string"}},
    },
}

_par = {"type": "array", "items": {"type": "string"}}
SCHEMA_TEXTOS = {"type": "object", "properties": {k: _par for k in (
    "sumario", "destaques", "financeiro", "margem", "incentivos_retorno", "incentivos_investimento",
    "funil", "clientes", "operacao", "itens", "anuncios")}, "required": ["sumario", "destaques"]}


def _cliente():
    import anthropic
    if not config.ANTHROPIC_API_KEY:
        raise RuntimeError("ANTHROPIC_API_KEY não configurada.")
    return anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY, max_retries=3, timeout=240)


def _ferramenta(modelo, sistema, conteudo, nome, schema, max_tokens):
    r = _cliente().messages.create(
        model=modelo, max_tokens=max_tokens,
        system=[{"type": "text", "text": sistema, "cache_control": {"type": "ephemeral"}}],
        tools=[{"name": nome, "description": "Registra o resultado no formato exigido.", "input_schema": schema}],
        tool_choice={"type": "tool", "name": nome},
        messages=[{"role": "user", "content": conteudo}],
    )
    for b in r.content:
        if getattr(b, "type", "") == "tool_use":
            return b.input
    raise RuntimeError("A IA não devolveu o formato esperado.")


def extrair(arquivos, contexto: str) -> dict:
    """arquivos: lista de ingest.Arquivo. Planilhas já lidas por código também vão, para contexto."""
    if config.MOCK_IA:
        return _mock_extracao()
    conteudo = [{"type": "text", "text": contexto}]
    for i, a in enumerate(arquivos, 1):
        conteudo.append({"type": "text", "text": f"--- Arquivo {i}: {a.nome}"})
        if a.tipo == "texto":
            conteudo.append({"type": "text", "text": a.texto[:60_000]})
        elif a.tipo == "imagem":
            conteudo.append({"type": "image", "source": {"type": "base64", "media_type": a.midia,
                                                         "data": base64.b64encode(a.dados).decode()}})
        else:
            conteudo.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf",
                                                            "data": base64.b64encode(a.dados).decode()}})
    sistema = (PROMPTS / "extracao.md").read_text(encoding="utf-8")
    return _ferramenta(config.MODELO_EXTRACAO, sistema, conteudo, "registrar_dados", SCHEMA_EXTRACAO, 8000)


def redigir(fatos: dict, correcao: str = "") -> dict:
    if config.MOCK_IA:
        return {}
    sistema = (PROMPTS / "redacao.md").read_text(encoding="utf-8")
    txt = "JSON de fatos (use só estes números, como estão no campo texto):\n" + json.dumps(fatos, ensure_ascii=False, indent=1)
    if correcao:
        txt += "\n\nA versão anterior foi recusada pela checagem automática. Corrija:\n" + correcao
    return _ferramenta(config.MODELO_REDACAO, sistema, [{"type": "text", "text": txt}], "registrar_textos",
                       SCHEMA_TEXTOS, 6000)


def _mock_extracao() -> dict:
    """Usado só em testes (MOCK_IA=1): simula a leitura dos prints."""
    return {
        "loja": {"nome": None, "id": None, "cidade": "Belém", "uf": "PA"},
        "financeiro_meses": [
            {"mes": 7, "ano": 2026, "vendas": 13197.18, "taxas": 2187.16, "promocoes": 2821.45, "ajustes": 12.72, "liquido": 8201.29},
            {"mes": 8, "ano": 2026, "vendas": 9857.12, "taxas": 1866.70, "promocoes": 1955.34, "ajustes": 48.85, "liquido": 6083.93},
            {"mes": 9, "ano": 2026, "vendas": 13256.16, "taxas": 2709.14, "promocoes": 3479.38, "ajustes": 0, "liquido": 7067.64}],
        "funil": {"atual": {"visitas": 3313, "visualizacoes": 1957, "sacola": 1012, "revisao": 952, "concluidos": 545},
                  "anterior": {"visitas": 5215, "visualizacoes": 4183, "sacola": 1882, "revisao": 1763, "concluidos": 859}},
        "promocoes": {"atual": {"investimento_loja": 5873.46, "investimento_ifood": 3309.51, "retorno": 4.22,
                                "classificacao": "Bom", "pedidos_com_promocao": 530, "pedidos_mais_de_uma": 399,
                                "vendas_com_promocao": 30633.85, "ticket": 57.80}},
        "clientes": {"data_anterior": "17/07/2026", "data_atual": "14/10/2026",
                     "anterior": {"novos": 95, "frequentes": 24, "em_alerta": 412, "sumidos": 511, "recuperados": 49},
                     "atual": {"novos": 85, "frequentes": 33, "em_alerta": 135, "sumidos": 477, "recuperados": 54}},
        "operacao": {"nivel_super": "Nível 4", "projecao_super": "Nível 2", "media_avaliacoes": 4.75, "qtd_avaliacoes": 4,
                     "cancelamentos_qtd": 11, "cancelamentos_valor": 442.66, "cancelamentos_impacto_super": 4, "negociacoes": 26},
        "avisos": [],
    }
