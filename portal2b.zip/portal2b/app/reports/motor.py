"""Monta o relatório de ponta a ponta, sem gravar nada em disco além de uma pasta temporária
que é apagada ao final (com sucesso ou erro)."""
import re, shutil, tempfile, pathlib
from dataclasses import dataclass, field
from datetime import date

from .. import config
from . import ingest, planilhas, ia, gerador
from .ingest import ErroArquivos

MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro",
         "outubro", "novembro", "dezembro"]
UFS = {"acre": "AC", "alagoas": "AL", "amapa": "AP", "amazonas": "AM", "bahia": "BA", "ceara": "CE",
       "distrito federal": "DF", "espirito santo": "ES", "goias": "GO", "maranhao": "MA", "mato grosso": "MT",
       "mato grosso do sul": "MS", "minas gerais": "MG", "para": "PA", "paraiba": "PB", "parana": "PR",
       "pernambuco": "PE", "piaui": "PI", "rio de janeiro": "RJ", "rio grande do norte": "RN",
       "rio grande do sul": "RS", "rondonia": "RO", "roraima": "RR", "santa catarina": "SC", "sao paulo": "SP",
       "sergipe": "SE", "tocantins": "TO"}
PROIBIDAS = ["recomend", "sugerimos", "sugere-se", "sugiro", "aconselh", "deveria", "ponto de atenção",
             "pontos de atenção", "oportunidade", "excelente", "ótimo", "preocupante", "crítico", "2bproud",
             "consultoria", "cada r$ 1 gerou", "cada r$ 1,00 gerou"]


@dataclass
class Pedido:
    tipo: str  # situacional | fechamento | periodo
    ini: date
    fim: date
    loja_id_conta: str | None
    loja_nome_conta: str | None


@dataclass
class Resultado:
    pdf: bytes
    nome_arquivo: str
    loja_id: str
    loja_nome: str
    loja_cidade: str
    loja_uf: str
    avisos: list = field(default_factory=list)


# ------------------------------------------------------------------ formatação
def brl(v):
    return gerador.brl(v)


def pct(v, casas=2):
    return f"{v:.{casas}f}%".replace(".", ",")


def intbr(v):
    return f"{int(round(v)):,}".replace(",", ".")


def var_pct(a, b):
    return None if not a else (b / a - 1) * 100


def dbr(d: date):
    return d.strftime("%d/%m/%Y")


def F(valor, texto, rotulo=""):
    return {"rotulo": rotulo, "valor": valor, "texto": texto}


def vtxt(a, b, casas=2):
    v = var_pct(a, b)
    return None if v is None else (("+" if v > 0 else "") + pct(v, casas))


# ------------------------------------------------------------------ checagens
def conferir_financeiro(meses, avisos):
    ok = []
    for m in meses:
        if m.get("vendas") is None or m.get("liquido") is None or not m.get("vendas"):
            continue
        if not isinstance(m.get("mes"), int) or not 1 <= m["mes"] <= 12 or not isinstance(m.get("ano"), int) \
                or not 2015 <= m["ano"] <= 2100:
            avisos.append("Um dos meses do Financeiro veio sem mês/ano legível e ficou fora do relatório.")
            continue
        t, p, aj = m.get("taxas") or 0, m.get("promocoes") or 0, m.get("ajustes") or 0
        dif = abs(m["vendas"] - abs(t) - abs(p) + aj - m["liquido"])
        if dif > 1.0:
            avisos.append(f"Financeiro de {MESES[m['mes'] - 1]}/{m['ano']}: a conta vendas − taxas − serviços e "
                          f"promoções + ajustes não fecha com o líquido (diferença de {brl(dif)}). Mês fora do relatório.")
            continue
        ok.append({**m, "taxas": abs(t), "promocoes": abs(p), "ajustes": aj})
    return sorted(ok, key=lambda m: (m["ano"], m["mes"]))


def conferir_funil(f, avisos):
    ordem = ("visitas", "visualizacoes", "sacola", "revisao", "concluidos")
    out = {}
    for k in ("atual", "anterior"):
        e = (f or {}).get(k) or {}
        vals = [e.get(x) for x in ordem]
        if any(v is None for v in vals):
            continue
        if any(vals[i] < vals[i + 1] for i in range(4)):
            avisos.append(f"Funil ({k}): as etapas não diminuem em ordem; confira o print. Funil {k} fora do relatório.")
            continue
        out[k] = vals
    return out


def _cli(c):
    if not c:
        return None
    vals = [c.get(k) for k in ("novos", "frequentes", "em_alerta", "sumidos", "recuperados")]
    return None if any(v is None for v in vals) else vals


# ------------------------------------------------------------------ fatos
def montar_fatos(p: Pedido, ex: dict, con: dict, avisos: list) -> dict:
    fatos = {"periodo": F(None, f"{dbr(p.ini)} a {dbr(p.fim)}"), "tipo": p.tipo}
    meses = conferir_financeiro(ex.get("financeiro_meses") or [], avisos)
    if p.tipo == "fechamento":
        meses = [m for m in meses if (m["ano"], m["mes"]) <= (p.fim.year, p.fim.month)]
        if not any((m["ano"], m["mes"]) == (p.fim.year, p.fim.month) for m in meses):
            raise ErroArquivos(f"Falta o Financeiro de {MESES[p.fim.month - 1]}/{p.fim.year} (o mês do fechamento).")
    meses = meses[-3:]
    if meses:
        fm = []
        for m in meses:
            mg = m["liquido"] / m["vendas"] * 100 if m["vendas"] else 0
            fm.append({"mes": f"{MESES[m['mes'] - 1].capitalize()}/{m['ano']}",
                       "vendas": F(m["vendas"], brl(m["vendas"])), "taxas": F(m["taxas"], brl(m["taxas"])),
                       "servicos_promocoes": F(m["promocoes"], brl(m["promocoes"])),
                       "ajustes": F(m["ajustes"], brl(m["ajustes"])), "liquido": F(m["liquido"], brl(m["liquido"])),
                       "margem": F(round(mg, 1), pct(mg, 1))})
        fatos["financeiro"] = fm
        if len(meses) >= 2:
            a, b = meses[0], meses[-1]
            mga, mgb = a["liquido"] / a["vendas"] * 100, b["liquido"] / b["vendas"] * 100
            fatos["financeiro_variacao"] = {
                "vendas": vtxt(a["vendas"], b["vendas"]), "liquido": vtxt(a["liquido"], b["liquido"]),
                "servicos_promocoes": vtxt(a["promocoes"], b["promocoes"]),
                "margem_pp": f"{round(mgb, 1) - round(mga, 1):+.1f} p.p.".replace(".", ",")}
    fu = conferir_funil(ex.get("funil"), avisos)
    if fu.get("atual"):
        at = fu["atual"]
        nomes = ["visitas", "visualizacoes", "sacola", "revisao", "concluidos"]
        fatos["funil"] = {"atual": {n: F(v, intbr(v)) for n, v in zip(nomes, at)},
                          "conversao_atual": F(at[4] / at[0] * 100 if at[0] else 0, pct(at[4] / at[0] * 100 if at[0] else 0))}
        if fu.get("anterior"):
            an = fu["anterior"]
            fatos["funil"]["anterior"] = {n: F(v, intbr(v)) for n, v in zip(nomes, an)}
            fatos["funil"]["variacao"] = {n: vtxt(x, y) for n, x, y in zip(nomes, an, at)}
            ca = an[4] / an[0] * 100 if an[0] else 0
            fatos["funil"]["conversao_anterior"] = F(ca, pct(ca))
    pr = (ex.get("promocoes") or {}).get("atual") or {}
    if pr.get("investimento_loja") is not None:
        pa = (ex.get("promocoes") or {}).get("anterior") or {}
        d = {}
        for k, fmt in (("investimento_loja", brl), ("investimento_ifood", brl), ("vendas_com_promocao", brl),
                       ("ticket", brl), ("pedidos_com_promocao", intbr), ("pedidos_mais_de_uma", intbr)):
            if pr.get(k) is not None:
                d[k] = F(pr[k], fmt(pr[k]))
                if pa.get(k) is not None:
                    d[k + "_anterior"] = F(pa[k], fmt(pa[k]))
                    d[k + "_variacao"] = vtxt(pa[k], pr[k])
        if pr.get("retorno") is not None:
            d["retorno"] = F(pr["retorno"], brl(pr["retorno"]))
            d["vendas_por_real"] = F(pr["retorno"] + 1, brl(pr["retorno"] + 1))
            if pr.get("classificacao"):
                d["classificacao"] = pr["classificacao"]
            if pa.get("retorno") is not None:
                d["retorno_anterior"] = F(pa["retorno"], brl(pa["retorno"]))
        if pr.get("investimento_ifood") is not None:
            tot = pr["investimento_loja"] + pr["investimento_ifood"]
            d["investimento_total"] = F(tot, brl(tot))
        fatos["promocoes"] = d
    cl = ex.get("clientes") or {}
    ca, cb = _cli(cl.get("anterior")), _cli(cl.get("atual"))
    if ca and cb:
        nomes = ["novos", "frequentes", "em_alerta", "sumidos", "recuperados"]
        fatos["clientes"] = {"data_anterior": cl.get("data_anterior") or "", "data_atual": cl.get("data_atual") or "",
                             "anterior": {n: F(v, intbr(v)) for n, v in zip(nomes, ca)},
                             "atual": {n: F(v, intbr(v)) for n, v in zip(nomes, cb)},
                             "variacao": {n: vtxt(x, y) for n, x, y in zip(nomes, ca, cb)}}
    op = {k: v for k, v in (ex.get("operacao") or {}).items() if v not in (None, "")}
    if op:
        o = {}
        for k, v in op.items():
            if k.endswith("_pct"):
                o[k] = F(v, pct(v, 1))
            elif k == "cancelamentos_valor":
                o[k] = F(v, brl(v))
            elif k == "media_avaliacoes":
                o[k] = F(v, f"{v:.2f}".replace(".", ","))
            elif k == "tempo_preparo_min":
                o[k] = F(v, f"{v:.0f} min")
            elif isinstance(v, (int, float)):
                o[k] = F(v, intbr(v))
            else:
                o[k] = F(None, str(v))
        fatos["operacao"] = o
    an = {k: v for k, v in (ex.get("anuncios") or {}).items() if v is not None}
    if an.get("investimento") is not None:
        fatos["anuncios"] = {k: F(v, brl(v) if k in ("investimento", "vendas", "custo_por_pedido", "retorno") else intbr(v))
                             for k, v in an.items()}
    if con.get("vendas"):
        v = con["vendas"]
        fatos["vendas"] = {"pedidos": F(v["pedidos"], intbr(v["pedidos"])), "valor": F(v["valor"], brl(v["valor"])),
                           "ticket": F(v["ticket"], brl(v["ticket"])),
                           "por_logistica": [{"logistica": x["logistica"], "pedidos": F(x["pedidos"], intbr(x["pedidos"])),
                                              "valor": F(x["valor"], brl(x["valor"]))} for x in v["por_logistica"]]}
    if con.get("itens"):
        top = con["itens"][:6]
        fatos["itens"] = [{"nome": i["nome"], "quantidade": F(i["quantidade"], intbr(i["quantidade"])),
                           "valor_total": F(i["valor_total"], brl(i["valor_total"]))} for i in top]
    if con.get("dias"):
        fatos["dias"] = [{"dia": d["dia"], "pedidos": F(d["pedidos"], intbr(d["pedidos"]))} for d in con["dias"]]
    return fatos


# ------------------------------------------------------------------ textos
TOKEN = re.compile(r"\d+(?:\.\d{3})*(?:,\d+)?")


def _tokens_permitidos(fatos) -> set:
    bruto = []

    def andar(x):
        if isinstance(x, dict):
            for k, v in x.items():
                andar(v)
        elif isinstance(x, list):
            for v in x:
                andar(v)
        elif isinstance(x, str):
            bruto.append(x)
    andar(fatos)
    permitidos = set(TOKEN.findall(" ".join(bruto)))
    permitidos |= {str(i) for i in range(0, 13)} | {"1,00", "90", "30", "2025", "2026", "2027"}
    for t in list(permitidos):  # "+12,50%" -> "12,50"; aceitar também sem sinal
        permitidos.add(t.lstrip("+-"))
    return permitidos


def checar_texto(paragrafos: list, permitidos: set) -> list:
    erros = []
    for p in paragrafos or []:
        low = p.lower()
        for w in PROIBIDAS:
            if w in low:
                erros.append(f'termo proibido "{w}" em: {p[:80]}')
        for t in TOKEN.findall(p):
            if t not in permitidos:
                erros.append(f'número "{t}" não está nos fatos: {p[:80]}')
    return erros


def textos_padrao(f: dict) -> dict:
    """Textos determinísticos, usados quando a redação da IA não passa na checagem."""
    t = {}
    per = f["periodo"]["texto"]
    if f.get("financeiro"):
        m = f["financeiro"]
        ult = m[-1]
        t["financeiro"] = [" ".join(
            f"Em **{x['mes']}**, o valor de vendas foi de **{x['vendas']['texto']}**, com serviços e promoções de "
            f"{x['servicos_promocoes']['texto']} e faturamento líquido de **{x['liquido']['texto']}**." for x in m)]
        t["margem"] = ["A margem após iFood (faturamento líquido sobre vendas, antes do custo dos produtos) foi de " +
                       ", ".join(f"**{x['margem']['texto']}** em {x['mes']}" for x in m) + "."]
        resumo = (f"No período de {per}, o último mês ({ult['mes']}) registrou **{ult['vendas']['texto']}** em vendas e "
                  f"**{ult['liquido']['texto']}** de faturamento líquido, com margem após iFood de **{ult['margem']['texto']}**.")
    else:
        resumo = f"Este relatório reúne os resultados da loja no iFood no período de {per}."
    t["sumario"] = [resumo]
    dest = []
    if f.get("vendas"):
        v = f["vendas"]
        t["sumario"].append(f"Foram **{v['pedidos']['texto']} pedidos**, somando **{v['valor']['texto']}**, "
                            f"com ticket médio de **{v['ticket']['texto']}**.")
        dest.append(f"**{v['pedidos']['texto']} pedidos** no período, ticket médio de {v['ticket']['texto']}.")
    if f.get("funil"):
        fu = f["funil"]
        etapas = ["visitas", "visualizacoes", "sacola", "revisao", "concluidos"]
        nomes = ["visitas", "visualizações", "itens na sacola", "pedidos revisados", "pedidos concluídos"]
        if fu.get("anterior"):
            t["funil"] = ["Na comparação com o período anterior: " + "; ".join(
                f"{n} passaram de {fu['anterior'][e]['texto']} para **{fu['atual'][e]['texto']}**"
                for e, n in zip(etapas, nomes)) +
                f". A conversão geral foi de {fu['conversao_anterior']['texto']} para **{fu['conversao_atual']['texto']}**."]
        else:
            t["funil"] = ["No período: " + "; ".join(f"**{fu['atual'][e]['texto']}** {n}" for e, n in zip(etapas, nomes)) +
                          f". Conversão geral de **{fu['conversao_atual']['texto']}**."]
        dest.append(f"**Conversão de {fu['conversao_atual']['texto']}** das visitas em pedidos concluídos.")
    if f.get("promocoes"):
        p = f["promocoes"]
        if p.get("retorno"):
            t["incentivos_retorno"] = [f"O retorno das promoções foi de **{p['retorno']['texto']} por real investido**, ou "
                                       f"seja, **{p['vendas_por_real']['texto']}** em vendas com promoção para cada R$ 1,00 "
                                       f"investido pela loja."]
        if p.get("investimento_total"):
            t["incentivos_investimento"] = [f"O investimento total em promoções foi de **{p['investimento_total']['texto']}**: "
                                            f"**{p['investimento_loja']['texto']}** da loja e "
                                            f"{p['investimento_ifood']['texto']} do iFood."]
        dest.append(f"**{p['investimento_loja']['texto']} investidos pela loja** em promoções.")
    if f.get("clientes"):
        c = f["clientes"]
        nomes = [("novos", "novos"), ("frequentes", "frequentes"), ("em_alerta", "em alerta"), ("sumidos", "sumidos"),
                 ("recuperados", "recuperados")]
        t["clientes"] = [f"Entre {c['data_anterior']} e {c['data_atual']}, os clientes " + "; ".join(
            f"{n} passaram de {c['anterior'][k]['texto']} para **{c['atual'][k]['texto']}**" for k, n in nomes) + "."]
    if f.get("operacao"):
        o = f["operacao"]
        partes = []
        if o.get("nivel_super"):
            partes.append(f"nível Super **{o['nivel_super']['texto']}**" +
                          (f" (projeção: {o['projecao_super']['texto']})" if o.get("projecao_super") else ""))
        if o.get("media_avaliacoes"):
            partes.append(f"média das avaliações de **{o['media_avaliacoes']['texto']}**")
        if o.get("cancelamentos_qtd"):
            partes.append(f"**{o['cancelamentos_qtd']['texto']} cancelamentos**" +
                          (f" ({o['cancelamentos_valor']['texto']})" if o.get("cancelamentos_valor") else ""))
        if o.get("negociacoes"):
            partes.append(f"{o['negociacoes']['texto']} negociações")
        if partes:
            t["operacao"] = ["No período, a operação registrou " + ", ".join(partes) + "."]
    if f.get("itens"):
        i = f["itens"][0]
        t["itens"] = [f"O item mais vendido foi **{i['nome']}**, com **{i['quantidade']['texto']} unidades** e "
                      f"{i['valor_total']['texto']} em vendas."]
    if f.get("anuncios"):
        a = f["anuncios"]
        t["anuncios"] = [f"Os anúncios somaram **{a['investimento']['texto']}** investidos" +
                         (f" e **{a['pedidos']['texto']} pedidos** atribuídos" if a.get("pedidos") else "") + "."]
    t["destaques"] = dest or [f"**Período analisado:** {per}."]
    return t


def textos_finais(fatos) -> tuple[dict, list]:
    permitidos = _tokens_permitidos(fatos)
    padrao = textos_padrao(fatos)
    notas = []
    try:
        tx = ia.redigir(fatos)
        erros = {k: checar_texto(v, permitidos) for k, v in tx.items()}
        ruins = {k: e for k, e in erros.items() if e}
        if ruins:
            tx2 = ia.redigir(fatos, "\n".join(x for e in ruins.values() for x in e[:5]))
            for k in ruins:
                if tx2.get(k) and not checar_texto(tx2[k], permitidos):
                    tx[k] = tx2[k]
                else:
                    tx[k] = padrao.get(k, [])
                    notas.append(k)
    except Exception as e:  # sem IA, o relatório sai com os textos padrão
        tx, notas = {}, [f"redação automática indisponível ({type(e).__name__})"]
    for k, v in padrao.items():
        if not tx.get(k):
            tx[k] = v
    return tx, notas


# ------------------------------------------------------------------ montagem do JSON do gerador
def montar_json(p: Pedido, fatos, tx, loja) -> dict:
    nome_mes = MESES[p.fim.month - 1]
    if p.tipo == "situacional":
        capa, sub, rot = "RELATÓRIO SITUACIONAL", "RETRATO DOS ÚLTIMOS 90 DIAS NO IFOOD", "Últimos 90 dias"
    elif p.tipo == "fechamento":
        capa, sub, rot = f"FECHAMENTO DE {nome_mes.upper()}", "RELATÓRIO DE RESULTADOS MENSAIS", f"{nome_mes.capitalize()}/{p.fim.year}"
    else:
        capa, sub, rot = "RELATÓRIO DE PERÍODO", f"{dbr(p.ini)} A {dbr(p.fim)}", f"{p.ini:%d/%m} a {p.fim:%d/%m}"
    secoes = {}
    fontes = "relatórios do Portal do Parceiro iFood enviados pela loja"
    secoes["sobre"] = [f"Este relatório apresenta os resultados de **{loja['nome']}** no iFood no período de "
                       f"**{fatos['periodo']['texto']}**, com comparação ao período anterior quando o dado existe. "
                       f"Fontes: {fontes}. Os números foram transcritos e conferidos automaticamente; margens consideram "
                       f"apenas o que o iFood desconta, antes do custo dos produtos."]
    if fatos.get("financeiro"):
        secoes["financeiro"] = {"margem": True, "meses": [
            {"mes": m["mes"].split("/")[0], "vendas": m["vendas"]["valor"], "taxas": m["taxas"]["valor"],
             "promocoes": m["servicos_promocoes"]["valor"], "ajustes": m["ajustes"]["valor"],
             "liquido": m["liquido"]["valor"]} for m in fatos["financeiro"]],
            "texto": tx.get("financeiro"), "texto_margem": tx.get("margem")}
    pr = fatos.get("promocoes")
    if pr:
        k = []
        k.append({"rotulo": "Total investido pela loja", "valor": pr["investimento_loja"]["texto"] +
                  (f" ({pr['investimento_loja_variacao']})" if pr.get("investimento_loja_variacao") else "")})
        if pr.get("retorno"):
            k.append({"rotulo": "Retorno por real investido", "valor": pr["retorno"]["texto"] +
                      (f" ({pr['classificacao']})" if pr.get("classificacao") else "")})
        if pr.get("pedidos_com_promocao"):
            k.append({"rotulo": "Pedidos com promoção", "valor": pr["pedidos_com_promocao"]["texto"] +
                      (f" ({pr['pedidos_mais_de_uma']['texto']} c/ +1 promoção)" if pr.get("pedidos_mais_de_uma") else "")})
        if pr.get("vendas_com_promocao"):
            k.append({"rotulo": "Valor de vendas com promoção", "valor": pr["vendas_com_promocao"]["texto"]})
        inc = {"kpis": k, "texto_retorno": tx.get("incentivos_retorno"), "texto_investimento": tx.get("incentivos_investimento")}
        if pr.get("retorno") and pr.get("retorno_anterior"):
            inc["retorno"] = {"anterior": pr["retorno_anterior"]["valor"], "atual": pr["retorno"]["valor"],
                              "rotulo_atual": rot}
        if pr.get("investimento_ifood"):
            inc["investimento"] = {"loja": pr["investimento_loja"]["valor"], "ifood": pr["investimento_ifood"]["valor"]}
        secoes["incentivos"] = inc
    fu = fatos.get("funil")
    if fu:
        e = ["visitas", "visualizacoes", "sacola", "revisao", "concluidos"]
        secoes["funil"] = {"atual": [fu["atual"][x]["valor"] for x in e],
                           "anterior": [fu["anterior"][x]["valor"] for x in e] if fu.get("anterior") else None,
                           "texto": tx.get("funil")}
    cl = fatos.get("clientes")
    if cl:
        n = ["novos", "frequentes", "em_alerta", "sumidos", "recuperados"]
        curta = lambda s: s[:5] if s else ""
        secoes["clientes"] = {"data_inicio": curta(cl["data_anterior"]), "data_fim": curta(cl["data_atual"]),
                              "anterior": [cl["anterior"][x]["valor"] for x in n],
                              "atual": [cl["atual"][x]["valor"] for x in n], "texto": tx.get("clientes")}
    op = fatos.get("operacao")
    if op:
        k = []
        if op.get("nivel_super"):
            k.append({"rotulo": "Nível no programa Super", "valor": op["nivel_super"]["texto"] +
                      (f" (projeção: {op['projecao_super']['texto']})" if op.get("projecao_super") else "")})
        if op.get("media_avaliacoes"):
            k.append({"rotulo": "Média das avaliações", "valor": op["media_avaliacoes"]["texto"] + " ★" +
                      (f" ({op['qtd_avaliacoes']['texto']} avaliações)" if op.get("qtd_avaliacoes") else "")})
        if op.get("cancelamentos_qtd"):
            k.append({"rotulo": "Cancelamentos", "valor": op["cancelamentos_qtd"]["texto"] +
                      (f" ({op['cancelamentos_valor']['texto']})" if op.get("cancelamentos_valor") else "")})
        for chave, rot_k in (("tempo_online_pct", "Tempo online vs. planejado"), ("negociacoes", "Negociações"),
                             ("entregas_no_prazo_pct", "Entregas no prazo"), ("chamados_respondidos_pct", "Chamados respondidos")):
            if len(k) < 4 and op.get(chave):
                k.append({"rotulo": rot_k, "valor": op[chave]["texto"]})
        if k:
            secoes["operacao"] = {"kpis": k, "texto": tx.get("operacao")}
    if fatos.get("itens"):
        secoes["itens"] = {"nomes": [i["nome"] for i in fatos["itens"]],
                           "valores": [i["quantidade"]["valor"] for i in fatos["itens"]], "texto": tx.get("itens")}
    return {
        "loja": loja, "mes": nome_mes, "ano": p.fim.year, "titulo_capa": capa, "subtitulo_capa": sub,
        "rotulo_atual": rot, "rotulo_periodo": fatos["periodo"]["texto"],
        "destaques_titulo": "Destaques do período" if p.tipo != "fechamento" else "Destaques do mês",
        "entidade_confidencialidade": f"de {loja['nome']}",
        "sumario": tx.get("sumario"), "destaques": tx.get("destaques"), "secoes": secoes,
        "cta": [f"Este relatório mostra **o que aconteceu** no período. Para entender **o que os números significam para "
                f"a sua loja e o que fazer a seguir**, agende a leitura com um consultor da 2bProud "
                f"(R$ {config.PRECO_LEITURA_CONSULTOR:.0f}) pelo WhatsApp {config.TELEFONE}."],
        "aviso": "Relatório gerado automaticamente no Portal 2b a partir dos arquivos enviados pela loja. Os arquivos "
                 "não ficam armazenados. A qualidade do relatório depende dos arquivos enviados.",
        "contato": {"empresa": config.EMPRESA, "telefone": config.TELEFONE, "instagram": config.INSTAGRAM},
    }


# ------------------------------------------------------------------ ponta a ponta
def gerar(p: Pedido, arquivos: list[tuple[str, bytes]]) -> Resultado:
    avisos = []
    arqs = ingest.carregar(arquivos, config.MAX_MB_ARQUIVO)
    ident = ingest.identidade(arqs)
    loja_id = ingest.conferir_loja(ident, p.loja_id_conta, p.loja_nome_conta)
    ingest.conferir_periodo(ingest.periodos(arqs), p.ini, p.fim)
    con = planilhas.ler_conhecidos(arqs)
    contexto = (f"Relatório pedido: {p.tipo}, período {dbr(p.ini)} a {dbr(p.fim)}. Loja ID {loja_id}"
                + (f", nome {next(iter(ident['nomes']))}" if ident["nomes"] else "") + ".")
    ex = ia.extrair(arqs, contexto)
    lid = str((ex.get("loja") or {}).get("id") or "").strip()
    if lid and lid != loja_id:
        raise ErroArquivos(f"Um dos prints parece ser de outra loja (ID {lid}). Envie só arquivos da loja {loja_id}.")
    nome_print = ingest.norm((ex.get("loja") or {}).get("nome") or "")
    nome_csv = ingest.norm(next(iter(ident["nomes"]))) if ident["nomes"] else ""
    if nome_print and nome_csv and nome_print not in nome_csv and nome_csv not in nome_print:
        raise ErroArquivos("O nome da loja nos prints não bate com o das planilhas. Envie só arquivos da mesma loja.")
    avisos += [a for a in ex.get("avisos") or [] if a]
    fatos = montar_fatos(p, ex, con, avisos)
    faltando = [n for k, n in (("financeiro", "Financeiro"), ("funil", "Funil da loja")) if not fatos.get(k)]
    if faltando:
        raise ErroArquivos("Faltam dados essenciais: " + ", ".join(faltando) + ". Confira a lista de arquivos e envie de novo."
                           + (" Avisos da leitura: " + " ".join(avisos) if avisos else ""))
    tx, notas = textos_finais(fatos)
    nome = (next(iter(ident["nomes"])) if ident["nomes"] else (ex.get("loja") or {}).get("nome")) or p.loja_nome_conta or "Loja"
    cidade = (next(iter(ident["cidades"])) if ident["cidades"] else (ex.get("loja") or {}).get("cidade")) or ""
    uf = (next(iter(ident["ufs"])) if ident["ufs"] else (ex.get("loja") or {}).get("uf")) or ""
    uf = UFS.get(ingest.norm(uf), uf.upper()[:2]) if len(uf) > 2 else uf.upper()
    loja = {"nome": nome.strip(), "cidade": cidade.strip().title(), "uf": uf, "id": loja_id}
    d = montar_json(p, fatos, tx, loja)
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="p2b_"))
    try:
        gerador.LOGO_SRC = gerador.carregar_logo(None)
        capa, corpo, rodape = gerador.montar(d, tmp)
        saida = tmp / "relatorio.pdf"
        gerador.pdf(capa, corpo, rodape, saida, tmp)
        pdf = saida.read_bytes()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    rot = {"situacional": "Situacional", "fechamento": f"Fechamento_{MESES[p.fim.month - 1].capitalize()}",
           "periodo": f"Periodo_{p.ini:%d%m}-{p.fim:%d%m%Y}"}[p.tipo]
    nome_arq = f"{rot}_{gerador.slug(loja['nome'])}_2bProud.pdf"
    if notas:
        avisos.append("Algumas seções usaram o texto padrão do sistema.")
    return Resultado(pdf, nome_arq, loja_id, loja["nome"], loja["cidade"], loja["uf"], avisos)
