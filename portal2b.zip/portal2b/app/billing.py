"""Cobrança pelo Asaas: assinatura (Loja e Franquia), relatório avulso e webhook.

Endereços e campos conforme a documentação do Asaas (v3). Antes de ir para produção, teste o fluxo
inteiro no sandbox (ASAAS_AMBIENTE=sandbox) com uma chave de sandbox.
"""
import re, secrets
from datetime import date, timedelta

import httpx
from sqlalchemy.exc import IntegrityError

from . import config
from .db import Usuario, Assinatura, Franquia, Convite, PagamentoAvulso, EventoWebhook


class ErroCobranca(Exception):
    pass


def _h():
    return {"access_token": config.ASAAS_API_KEY, "Content-Type": "application/json", "User-Agent": "portal-2bproud"}


def _req(metodo, caminho, **kw):
    if not config.ASAAS_API_KEY:
        raise ErroCobranca("Cobrança não configurada (ASAAS_API_KEY).")
    r = httpx.request(metodo, config.ASAAS_URL + caminho, headers=_h(), timeout=30, **kw)
    if r.status_code >= 400:
        try:
            msg = "; ".join(e.get("description", "") for e in r.json().get("errors", []))
        except Exception:
            msg = r.text[:300]
        raise ErroCobranca(f"Asaas recusou a operação: {msg or r.status_code}")
    return r.json() if r.content else {}


def so_digitos(s: str) -> str:
    return re.sub(r"\D", "", s or "")


def garantir_cliente(db, u: Usuario) -> str:
    if u.asaas_cliente_id:
        return u.asaas_cliente_id
    doc = so_digitos(u.cpf_cnpj)
    if len(doc) not in (11, 14):
        raise ErroCobranca("Informe um CPF ou CNPJ válido para emitir a cobrança.")
    if config.MOCK_ASAAS:
        u.asaas_cliente_id = "cus_mock_" + secrets.token_hex(4)
    else:
        c = _req("POST", "/customers", json={"name": u.nome, "cpfCnpj": doc, "email": u.email,
                                             "mobilePhone": so_digitos(u.telefone) or None,
                                             "externalReference": f"usuario:{u.id}"})
        u.asaas_cliente_id = c["id"]
    db.add(u)
    db.commit()
    return u.asaas_cliente_id


def _primeiro_link(sub_id: str) -> str:
    r = _req("GET", f"/subscriptions/{sub_id}/payments")
    itens = r.get("data") or []
    return (itens[0].get("invoiceUrl") if itens else "") or ""


def criar_assinatura(db, u: Usuario, tipo: str, ciclo: str, lojas: int, valor: float, descricao: str) -> tuple[Assinatura, str]:
    cliente = garantir_cliente(db, u)
    a = Assinatura(usuario_id=u.id, tipo=tipo, ciclo=ciclo, lojas=lojas, valor=valor)
    db.add(a)
    db.commit()
    if config.MOCK_ASAAS:
        a.asaas_id = "sub_mock_" + secrets.token_hex(4)
        ativar_periodo(a, config.hoje())
        db.commit()
        return a, f"{config.BASE_URL}/painel?ok=Assinatura+ativada+(modo+de+teste)"
    s = _req("POST", "/subscriptions", json={
        "customer": cliente, "billingType": "UNDEFINED", "value": valor, "nextDueDate": config.hoje().isoformat(),
        "cycle": ciclo, "description": descricao, "externalReference": f"assinatura:{a.id}"})
    a.asaas_id = s["id"]
    db.commit()
    return a, _primeiro_link(s["id"]) or f"{config.BASE_URL}/painel?ok=Cobran%C3%A7a+enviada+por+e-mail"


def link_pendente(a: Assinatura) -> str:
    if config.MOCK_ASAAS or not a.asaas_id:
        return ""
    return _primeiro_link(a.asaas_id)


def criar_franquia(db, gestor: Usuario, nome: str, lojas: int, ciclo: str) -> tuple[Franquia, str]:
    valor = config.valor_franquia(lojas, ciclo)
    desc = f"Portal 2b - Franquia {nome} ({lojas} lojas, {'anual' if ciclo == 'YEARLY' else 'mensal'})"
    a, link = criar_assinatura(db, gestor, "franquia", ciclo, lojas, valor, desc)
    f = Franquia(nome=nome, gestor_id=gestor.id, assinatura_id=a.id, lojas=lojas)
    db.add(f)
    db.commit()
    for _ in range(lojas):
        db.add(Convite(codigo=gerar_codigo(), franquia_id=f.id))
    gestor.papel = "gestor" if gestor.papel == "cliente" else gestor.papel
    db.commit()
    return f, link


def gerar_codigo() -> str:
    alfa = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "2B-" + "".join(secrets.choice(alfa) for _ in range(8))


def criar_avulso(db, u: Usuario) -> str:
    cliente = garantir_cliente(db, u)
    pg = PagamentoAvulso(usuario_id=u.id)
    db.add(pg)
    db.commit()
    if config.MOCK_ASAAS:
        pg.asaas_id, pg.status = "pay_mock_" + secrets.token_hex(4), "pago"
        u.creditos_avulsos += 1
        db.commit()
        return f"{config.BASE_URL}/painel?ok=Cr%C3%A9dito+liberado+(modo+de+teste)"
    p = _req("POST", "/payments", json={
        "customer": cliente, "billingType": "UNDEFINED", "value": config.PRECO_AVULSO,
        "dueDate": (config.hoje() + timedelta(days=2)).isoformat(),
        "description": "Portal 2b - relatório avulso", "externalReference": f"avulso:{pg.id}"})
    pg.asaas_id, pg.link = p["id"], p.get("invoiceUrl", "")
    db.commit()
    return pg.link or f"{config.BASE_URL}/painel"


def cancelar_assinatura(db, a: Assinatura):
    if a.asaas_id and not config.MOCK_ASAAS:
        _req("DELETE", f"/subscriptions/{a.asaas_id}")
    a.status = "cancelada"  # o acesso continua até pago_ate
    db.commit()


def ativar_periodo(a: Assinatura, vencimento: date):
    dias = 366 if a.ciclo == "YEARLY" else 31
    novo = vencimento + timedelta(days=dias + config.DIAS_TOLERANCIA)
    a.pago_ate = max(a.pago_ate or novo, novo)
    a.status = "ativa"


def processar_webhook(db, corpo: dict):
    """Idempotente: cada evento do Asaas é processado uma vez."""
    eid = corpo.get("id") or ""
    if eid:
        if db.get(EventoWebhook, eid):
            return "repetido"
        db.add(EventoWebhook(id=eid))
        try:
            db.flush()  # entrega duplicada simultânea: a segunda falha aqui e é tratada como repetida
        except IntegrityError:
            db.rollback()
            return "repetido"
    ev = corpo.get("event", "")
    pg = corpo.get("payment") or {}
    sub = corpo.get("subscription") or {}
    if ev in ("PAYMENT_CONFIRMED", "PAYMENT_RECEIVED"):
        if pg.get("subscription"):
            a = db.query(Assinatura).filter(Assinatura.asaas_id == pg["subscription"]).first()
            if a and a.status != "cancelada":  # pagamento tardio não reativa assinatura cancelada
                ven = date.fromisoformat(pg.get("dueDate") or config.hoje().isoformat())
                ativar_periodo(a, ven)
        else:
            p = db.query(PagamentoAvulso).filter(PagamentoAvulso.asaas_id == pg.get("id")).first()
            if p and p.status != "pago":
                p.status = "pago"
                u = db.get(Usuario, p.usuario_id)
                u.creditos_avulsos += 1
    elif ev == "PAYMENT_OVERDUE" and pg.get("subscription"):
        a = db.query(Assinatura).filter(Assinatura.asaas_id == pg["subscription"]).first()
        if a and a.status == "ativa":
            a.status = "atrasada"
    elif ev in ("PAYMENT_REFUNDED", "PAYMENT_CHARGEBACK_REQUESTED"):
        if pg.get("subscription"):
            a = db.query(Assinatura).filter(Assinatura.asaas_id == pg["subscription"]).first()
            if a:
                a.pago_ate, a.status = config.hoje() - timedelta(days=1), "cancelada"
        else:
            p = db.query(PagamentoAvulso).filter(PagamentoAvulso.asaas_id == pg.get("id")).first()
            if p and p.status == "pago":
                p.status = "estornado"
                u = db.get(Usuario, p.usuario_id)
                u.creditos_avulsos = max(0, u.creditos_avulsos - 1)
    elif ev in ("SUBSCRIPTION_DELETED", "SUBSCRIPTION_INACTIVATED"):
        a = db.query(Assinatura).filter(Assinatura.asaas_id == sub.get("id")).first()
        if a:
            a.status = "cancelada"
    db.commit()
    return ev or "sem-evento"
