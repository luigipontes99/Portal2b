"""Cria (ou promove) a conta de administrador.

uso: python -m app.criar_admin seu@email.com SenhaForte123
"""
import sys

from . import auth
from .db import SessionLocal, Usuario, criar_tabelas


def criar(email: str, senha: str):
    criar_tabelas()
    db = SessionLocal()
    try:
        email = email.strip().lower()
        u = db.query(Usuario).filter(Usuario.email == email).first()
        if not u:
            u = Usuario(email=email, nome="Administrador", senha_hash=auth.hash_senha(senha))
            db.add(u)
        else:
            u.senha_hash = auth.hash_senha(senha)
        u.papel = "admin"
        db.commit()
        return u.id
    finally:
        db.close()


if __name__ == "__main__":
    if len(sys.argv) != 3 or len(sys.argv[2]) < 10:
        sys.exit("uso: python -m app.criar_admin email senha (senha com 10+ caracteres)")
    print("admin pronto, id", criar(sys.argv[1], sys.argv[2]))
