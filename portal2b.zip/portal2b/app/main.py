"""Portal 2b: rotas web."""
import calendar, html, pathlib, queue, re, secrets, threading, time
from datetime import date, datetime, timedelta
from urllib.parse import quote

from fastapi import FastAPI, Request, Depends, Form, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from itsdangerous import URLSafeSerializer, BadSignature
from sqlalchemy import update
from sqlalchemy.exc import IntegrityError

from . import config, auth, acesso, billing
from .db import (SessionLocal, get_db, criar_tabelas, Usuario, Convite, Franquia, Assinatura, UsoRelatorio,
                 SituacionalGratis)
from .reports import motor, ingest
from .reports.ingest import ErroArquivos

BASE = pathlib.Path(__file__).resolve().parent
app = FastAPI(title="Portal 2b", docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
tpl = Jinja2Templates(directory=BASE / "templates")
tpl.env.globals.update(config=config, TIPOS=acesso.TIPOS)
tpl.env.filters["brl"] = lambda v: motor.brl(v)
_assinador = URLSafeSerializer(config.SECRET_KEY, salt="aviso")

criar_tabelas()  # idempotente; cria as tabelas na primeira subida


def _admin_inicial():
    if not (config.ADMIN_EMAIL and len(config.ADMIN_SENHA) >= 10):
        return
    db = SessionLocal()
    try:
        if db.query(Usuario).filter(Usuario.papel == "admin").count() == 0:
            from .criar_admin import criar
            criar(config.ADMIN_EMAIL, config.ADMIN_SENHA)
    finally:
        db.close()


_admin_inicial()


# ------------------------------------------------------------------ utilidades
def redir(url, ok=None, erro=None):
    """Mensagens vão assinadas na URL: ninguém consegue forjar um aviso no site com um link."""
    if ok or erro:
        url += ("&" if "?" in url else "?") + "m=" + _assinador.dumps({"ok": ok, "erro": erro})
    return RedirectResponse(url, status_code=303)


def render(request, nome, ctx=None, status=200, u=None, s=None):
    ctx = dict(ctx or {})
    msg = {}
    if request.query_params.get("m"):
        try:
            msg = _assinador.loads(request.query_params["m"])
        except BadSignature:
            msg = {}
    ctx.update(usuario=u, csrf=s.csrf if s else "", ok=ctx.get("ok") or msg.get("ok"),
               erro=ctx.get("erro") or msg.get("erro"), admin=auth.eh_admin(u))
    return tpl.TemplateResponse(request, nome, ctx, status_code=status)


def logado(request: Request, db=Depends(get_db)):
    u, s = auth.sessao_atual(request, db)
    if not u:
        raise HTTPException(status_code=303, headers={"Location": "/entrar"})
    return u, s


def _cookie(r, token):
    r.set_cookie(auth.COOKIE, token, httponly=True, secure=config.COOKIE_SECURE, samesite="lax",
                 max_age=60 * 60 * 24 * config.DIAS_SESSAO)


@app.exception_handler(HTTPException)
async def _http(request, exc):
    if exc.status_code == 303:
        return RedirectResponse(exc.headers["Location"], status_code=303)
    return HTMLResponse(f"<p style='font-family:sans-serif'>{html.escape(str(exc.detail))}</p>"
                        "<p><a href='/painel'>Voltar</a></p>", status_code=exc.status_code)


@app.middleware("http")
async def _seguranca(request, call_next):
    tam = request.headers.get("content-length")
    if tam and tam.isdigit() and int(tam) > config.MAX_MB_ENVIO * 1024 * 1024:
        return HTMLResponse(f"<p>Envio maior que {config.MAX_MB_ENVIO} MB.</p><p><a href='/relatorios'>Voltar</a></p>",
                            status_code=413)
    r = await call_next(request)
    r.headers.setdefault("X-Frame-Options", "DENY")
    r.headers.setdefault("X-Content-Type-Options", "nosniff")
    r.headers.setdefault("Referrer-Policy", "same-origin")
    return r


def _usar_convite(db, codigo: str, uid: int) -> int | None:
    """Marca o convite como usado de forma atômica. Devolve o id da franquia ou None."""
    codigo = codigo.strip().upper()
    r = db.execute(update(Convite).where(Convite.codigo == codigo, Convite.usado_por.is_(None))
                   .values(usado_por=uid, usado_em=datetime.utcnow()))
    if r.rowcount != 1:
        db.rollback()
        return None
    conv = db.get(Convite, codigo)
    return conv.franquia_id


# ------------------------------------------------------------------ páginas públicas
@app.get("/", response_class=HTMLResponse)
def inicio(request: Request, db=Depends(get_db)):
    u, s = auth.sessao_atual(request, db)
    return render(request, "inicio.html", u=u, s=s)


@app.get("/ifood", response_class=HTMLResponse)
def ifood(request: Request, db=Depends(get_db)):
    u, s = auth.sessao_atual(request, db)
    return render(request, "ifood.html", {"faixas": config.FRANQUIA_FAIXAS}, u=u, s=s)


@app.get("/termos", response_class=HTMLResponse)
def termos(request: Request, db=Depends(get_db)):
    u, s = auth.sessao_atual(request, db)
    return render(request, "termos.html", u=u, s=s)


@app.get("/privacidade", response_class=HTMLResponse)
def privacidade(request: Request, db=Depends(get_db)):
    u, s = auth.sessao_atual(request, db)
    return render(request, "privacidade.html", u=u, s=s)


@app.get("/saude")
def saude():
    return {"ok": True}


# ------------------------------------------------------------------ conta
@app.get("/cadastro", response_class=HTMLResponse)
def cadastro_form(request: Request):
    return render(request, "cadastro.html", {"codigo": request.query_params.get("codigo", "")[:20]})


@app.post("/cadastro")
def cadastro(request: Request, nome: str = Form(...), email: str = Form(...), telefone: str = Form(""),
             senha: str = Form(...), senha2: str = Form(...), codigo: str = Form(""), aceite: str = Form(""),
             db=Depends(get_db)):
    email = email.strip().lower()[:200]
    erro = None
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        erro = "E-mail inválido."
    elif len(senha) < 8:
        erro = "A senha precisa ter pelo menos 8 caracteres."
    elif senha != senha2:
        erro = "As senhas não conferem."
    elif not aceite:
        erro = "É preciso aceitar os termos de uso e a política de privacidade."
    elif db.query(Usuario).filter(Usuario.email == email).first():
        erro = "Já existe uma conta com este e-mail."
    elif codigo.strip():
        c = db.get(Convite, codigo.strip().upper())
        if not c or c.usado_por:
            erro = "Código de franquia inválido ou já usado."
    if erro:
        return render(request, "cadastro.html", {"erro": erro, "nome": nome, "email": email, "telefone": telefone,
                                                 "codigo": codigo}, status=400)
    u = Usuario(email=email, nome=nome.strip()[:200], telefone=telefone.strip()[:40], senha_hash=auth.hash_senha(senha))
    db.add(u)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return render(request, "cadastro.html", {"erro": "Já existe uma conta com este e-mail."}, status=400)
    if codigo.strip():
        fid = _usar_convite(db, codigo, u.id)
        if fid:
            u.franquia_id = fid
            db.add(u)
        db.commit()
    s = auth.abrir_sessao(db, u)
    r = redir("/painel", ok="Conta criada. Seu primeiro relatório situacional é grátis." if not u.franquia_id
              else "Conta criada e ligada à franquia.")
    _cookie(r, s.token)
    return r


@app.get("/entrar", response_class=HTMLResponse)
def entrar_form(request: Request):
    return render(request, "entrar.html")


@app.post("/entrar")
def entrar(request: Request, email: str = Form(...), senha: str = Form(...), db=Depends(get_db)):
    ip = request.client.host if request.client else "?"
    email = email.strip().lower()[:200]
    chaves = ("ip:" + ip, "email:" + email)
    if not auth.pode_tentar_login(*chaves):
        return render(request, "entrar.html", {"erro": "Muitas tentativas. Aguarde alguns minutos."}, status=429)
    u = db.query(Usuario).filter(Usuario.email == email).first()
    if not u or not u.ativo or not auth.confere_senha(senha, u.senha_hash):
        auth.registrar_tentativa(*chaves)
        return render(request, "entrar.html", {"erro": "E-mail ou senha incorretos.", "email": email}, status=400)
    s = auth.abrir_sessao(db, u)
    r = redir("/painel")
    _cookie(r, s.token)
    return r


@app.post("/sair")
def sair(request: Request, csrf: str = Form(""), db=Depends(get_db)):
    u, s = auth.sessao_atual(request, db)
    if s:
        auth.exigir_csrf(s, csrf)
        db.delete(s)
        db.commit()
    r = redir("/")
    r.delete_cookie(auth.COOKIE)
    return r


@app.post("/conta/senha")
def trocar_senha(request: Request, atual: str = Form(...), nova: str = Form(...), csrf: str = Form(""),
                 ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    if not auth.confere_senha(atual, u.senha_hash):
        return redir("/painel", erro="Senha atual incorreta.")
    if len(nova) < 8:
        return redir("/painel", erro="A nova senha precisa ter pelo menos 8 caracteres.")
    u.senha_hash = auth.hash_senha(nova)
    db.add(u)
    db.commit()
    return redir("/painel", ok="Senha alterada.")


@app.post("/conta/codigo")
def usar_codigo(request: Request, codigo: str = Form(...), csrf: str = Form(""), ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    if u.franquia_id:
        return redir("/painel", erro="Esta conta já está ligada a uma franquia.")
    fid = _usar_convite(db, codigo, u.id)
    if not fid:
        return redir("/painel", erro="Código inválido ou já usado.")
    u.franquia_id = fid
    db.add(u)
    db.commit()
    return redir("/painel", ok="Loja ligada à franquia.")


@app.get("/painel", response_class=HTMLResponse)
def painel(request: Request, ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    plano = acesso.resumo_plano(db, u)
    minhas = db.query(Assinatura).filter(Assinatura.usuario_id == u.id).order_by(Assinatura.id.desc()).all()
    franquias = db.query(Franquia).filter(Franquia.gestor_id == u.id).all()
    franquia_da_loja = db.get(Franquia, u.franquia_id) if u.franquia_id else None
    return render(request, "painel.html", {"plano": plano, "assinaturas": minhas, "franquias": franquias,
                                           "franquia_da_loja": franquia_da_loja}, u=u, s=s)


# ------------------------------------------------------------------ planos e cobrança
@app.get("/planos", response_class=HTMLResponse)
def planos(request: Request, db=Depends(get_db)):
    u, s = auth.sessao_atual(request, db)
    return render(request, "planos.html", {"faixas": config.FRANQUIA_FAIXAS}, u=u, s=s)


def _salvar_doc(db, u, cpf_cnpj):
    if cpf_cnpj:
        u.cpf_cnpj = billing.so_digitos(cpf_cnpj)[:14]
        db.add(u)
        db.commit()


def _pendente(db, u, tipo):
    """Assinatura criada nos últimos 3 dias e ainda não paga: reaproveita em vez de gerar outra cobrança."""
    lim = datetime.utcnow() - timedelta(days=3)
    return db.query(Assinatura).filter(Assinatura.usuario_id == u.id, Assinatura.tipo == tipo,
                                       Assinatura.status == "pendente", Assinatura.criado_em >= lim).first()


def _ir_para_pendente(a):
    try:
        link = billing.link_pendente(a)
    except billing.ErroCobranca:
        link = ""
    if link:
        return RedirectResponse(link, status_code=303)
    return redir("/painel", erro="Já existe uma cobrança aguardando pagamento (enviada ao seu e-mail pelo Asaas). "
                                 "Se quiser trocar de plano, cancele-a no painel.")


@app.post("/assinar")
def assinar(request: Request, ciclo: str = Form(...), cpf_cnpj: str = Form(""), csrf: str = Form(""),
            ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    if ciclo not in ("MONTHLY", "YEARLY"):
        raise HTTPException(400, "Ciclo inválido.")
    if acesso.assinatura_vigente(db, u):
        return redir("/painel", erro="Você já tem um plano ativo.")
    pend = _pendente(db, u, "loja")
    if pend:
        return _ir_para_pendente(pend)
    _salvar_doc(db, u, cpf_cnpj)
    valor = config.PRECO_LOJA_ANUAL if ciclo == "YEARLY" else config.PRECO_LOJA_MENSAL
    try:
        _, link = billing.criar_assinatura(db, u, "loja", ciclo, 1, valor,
                                           f"Portal 2b - Plano Loja ({'anual' if ciclo == 'YEARLY' else 'mensal'})")
    except billing.ErroCobranca as e:
        return redir("/planos", erro=str(e))
    return RedirectResponse(link, status_code=303)


@app.post("/franquia")
def franquia(request: Request, nome: str = Form(...), lojas: int = Form(...), ciclo: str = Form(...),
             cpf_cnpj: str = Form(""), csrf: str = Form(""), ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    if lojas < 3 or lojas > 500 or ciclo not in ("MONTHLY", "YEARLY"):
        return redir("/planos", erro="O plano Franquia é a partir de 3 lojas.")
    pend = _pendente(db, u, "franquia")
    if pend:
        return _ir_para_pendente(pend)
    _salvar_doc(db, u, cpf_cnpj)
    try:
        _, link = billing.criar_franquia(db, u, nome.strip()[:120] or "Franquia", lojas, ciclo)
    except billing.ErroCobranca as e:
        return redir("/planos", erro=str(e))
    return RedirectResponse(link, status_code=303)


@app.post("/avulso")
def avulso(request: Request, cpf_cnpj: str = Form(""), csrf: str = Form(""), ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    _salvar_doc(db, u, cpf_cnpj)
    try:
        link = billing.criar_avulso(db, u)
    except billing.ErroCobranca as e:
        return redir("/planos", erro=str(e))
    return RedirectResponse(link, status_code=303)


@app.post("/assinatura/{aid}/cancelar")
def cancelar(aid: int, request: Request, csrf: str = Form(""), ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    a = db.get(Assinatura, aid)
    if not a or a.usuario_id != u.id:
        raise HTTPException(404, "Assinatura não encontrada.")
    try:
        billing.cancelar_assinatura(db, a)
    except billing.ErroCobranca as e:
        return redir("/painel", erro=str(e))
    fim = a.pago_ate.strftime("%d/%m/%Y") if a.pago_ate else "hoje"
    return redir("/painel", ok=f"Assinatura cancelada. O acesso continua até {fim}.")


@app.post("/webhooks/asaas")
async def webhook_asaas(request: Request):
    tok = request.headers.get("asaas-access-token", "")
    if not config.ASAAS_WEBHOOK_TOKEN or not secrets.compare_digest(tok, config.ASAAS_WEBHOOK_TOKEN):
        return JSONResponse({"erro": "token"}, status_code=401)
    corpo = await request.json()
    db = SessionLocal()
    try:
        r = billing.processar_webhook(db, corpo)
    finally:
        db.close()
    return {"ok": True, "evento": r}


# ------------------------------------------------------------------ precificação
@app.get("/precificacao", response_class=HTMLResponse)
def precificacao(request: Request, ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    liberado = bool(acesso.assinatura_vigente(db, u)) or auth.eh_admin(u)
    return render(request, "precificacao.html", {"liberado": liberado}, u=u, s=s)


# ------------------------------------------------------------------ relatórios
# Fila própria: pedidos esperando não ocupam as threads do servidor web.
TRABALHOS: dict[str, dict] = {}
_trava_trab = threading.Lock()
_fila: "queue.Queue[tuple]" = queue.Queue()


def _trabalhador():
    while True:
        args = _fila.get()
        try:
            _executar(*args)
        finally:
            _fila.task_done()


for _ in range(config.GERACOES_SIMULTANEAS):
    threading.Thread(target=_trabalhador, daemon=True).start()


def _limpar_trabalhos():
    agora = time.time()
    with _trava_trab:
        for k in [k for k, v in TRABALHOS.items() if v["expira"] < agora]:
            TRABALHOS.pop(k, None)


def _trabalho(job, uid):
    _limpar_trabalhos()
    with _trava_trab:
        t = TRABALHOS.get(job)
        return dict(t) if t and t["usuario_id"] == uid else None


def periodo_do_pedido(tipo, fim_s, mes_s, ini_s):
    hoje = config.hoje()
    try:
        if tipo == "situacional":
            fim = date.fromisoformat(fim_s) if fim_s else hoje - timedelta(days=1)
            ini = fim - timedelta(days=89)
        elif tipo == "fechamento":
            a, m = (int(x) for x in mes_s.split("-"))
            ini, fim = date(a, m, 1), date(a, m, calendar.monthrange(a, m)[1])
        else:
            ini, fim = date.fromisoformat(ini_s), date.fromisoformat(fim_s)
    except Exception:
        raise ErroArquivos("Período inválido.")
    if fim < ini or (fim - ini).days > 92:
        raise ErroArquivos("O período precisa ter até 93 dias, com início antes do fim.")
    if fim >= hoje:
        raise ErroArquivos("O período precisa terminar antes de hoje (dias completos).")
    return ini, fim


@app.get("/relatorios", response_class=HTMLResponse)
def relatorios(request: Request, ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    _limpar_trabalhos()
    with _trava_trab:
        meus = [dict(id=k, **{x: v[x] for x in ("status", "tipo", "nome", "criado", "msg")})
                for k, v in TRABALHOS.items() if v["usuario_id"] == u.id]
    hoje = config.hoje()
    ult = hoje.replace(day=1) - timedelta(days=1)
    return render(request, "relatorios.html", {
        "plano": acesso.resumo_plano(db, u), "trabalhos": sorted(meus, key=lambda x: -x["criado"]),
        "ontem": (hoje - timedelta(days=1)).isoformat(), "mes_passado": ult.strftime("%Y-%m"),
        "tipo_sel": request.query_params.get("tipo", "situacional")}, u=u, s=s)


def _fim(job_id, **campos):
    with _trava_trab:
        if job_id in TRABALHOS:
            TRABALHOS[job_id].update(**campos)


def _executar(job_id: str, uid: int, pedido: motor.Pedido, arquivos, cobranca: str):
    db = SessionLocal()
    try:
        r = motor.gerar(pedido, arquivos)
        u = db.get(Usuario, uid)
        if u.loja_id and u.loja_id != r.loja_id:
            raise ErroArquivos(f"Estes arquivos são da loja {r.loja_id}, mas sua conta está vinculada à loja {u.loja_id}.")
        outro = db.query(Usuario).filter(Usuario.loja_id == r.loja_id, Usuario.id != uid).first()
        if outro:
            raise ErroArquivos(f"A loja {r.loja_id} já está vinculada a outra conta. Se ela é sua, fale com o suporte.")
        if not u.loja_id:
            u.loja_id, u.loja_nome, u.loja_cidade, u.loja_uf = r.loja_id, r.loja_nome, r.loja_cidade, r.loja_uf
            db.add(u)
            db.commit()
        try:
            acesso.cobrar(db, u, r.loja_id, ingest.norm(r.loja_nome), pedido.tipo, cobranca)
        except ValueError:
            db.rollback()
            msg = (f"A loja {r.loja_id} já usou o relatório situacional grátis. Assine um plano ou compre um relatório "
                   "avulso." if cobranca == "gratis" else "Seu saldo de relatórios acabou. Assine um plano ou compre um avulso.")
            raise ErroArquivos(msg)
        _fim(job_id, status="pronto", pdf=r.pdf, nome=r.nome_arquivo, msg=" ".join(r.avisos),
             expira=time.time() + config.MINUTOS_PDF_DISPONIVEL * 60)
    except ErroArquivos as e:
        db.rollback()
        _fim(job_id, status="erro", msg=str(e))
    except IntegrityError:
        db.rollback()
        _fim(job_id, status="erro", msg="Esta loja já está vinculada a outra conta.")
    except BaseException as e:  # noqa: inclui SystemExit vindo de bibliotecas
        db.rollback()
        _fim(job_id, status="erro", msg="Não foi possível gerar o relatório agora. Nenhum crédito foi usado. "
                                        f"Tente de novo em alguns minutos. ({type(e).__name__})")
    finally:
        arquivos.clear()  # libera a memória dos arquivos
        db.close()


@app.post("/relatorios")
async def novo_relatorio(request: Request, tipo: str = Form(...), fim: str = Form(""), mes: str = Form(""),
                         ini: str = Form(""), csrf: str = Form(""), arquivos: list[UploadFile] = File(...),
                         ctx=Depends(logado), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    if tipo not in acesso.TIPOS:
        raise HTTPException(400, "Tipo inválido.")
    cob = acesso.forma_de_cobranca(db, u, tipo)
    if not cob:
        return redir("/planos", erro="Para gerar este relatório, assine um plano ou compre um relatório avulso.")
    try:
        ini_d, fim_d = periodo_do_pedido(tipo, fim, mes, ini)
    except ErroArquivos as e:
        return redir(f"/relatorios?tipo={tipo}", erro=str(e))
    if len(arquivos) > config.MAX_ARQUIVOS:
        return redir(f"/relatorios?tipo={tipo}", erro=f"Envie no máximo {config.MAX_ARQUIVOS} arquivos.")
    job = secrets.token_urlsafe(12)
    with _trava_trab:  # um relatório por vez por conta (checagem e reserva juntas)
        if any(v["usuario_id"] == u.id and v["status"] == "processando" for v in TRABALHOS.values()):
            return redir("/relatorios", erro="Já existe um relatório sendo gerado. Aguarde ele terminar.")
        TRABALHOS[job] = {"usuario_id": u.id, "status": "processando", "tipo": acesso.TIPOS[tipo], "nome": "",
                          "criado": time.time(), "msg": "", "pdf": None, "expira": time.time() + 3600}
    dados = []
    try:
        for f in arquivos:
            b = await f.read(config.MAX_MB_ARQUIVO * 1024 * 1024 + 1)
            if b:
                dados.append((f.filename or "arquivo", b))
            await f.close()
    except Exception:
        _fim(job, status="erro", msg="Falha ao receber os arquivos. Tente de novo.")
        return redir(f"/relatorios/{job}")
    pedido = motor.Pedido(tipo, ini_d, fim_d, u.loja_id, u.loja_nome or None)
    _fila.put((job, u.id, pedido, dados, cob))
    return redir(f"/relatorios/{job}")


@app.get("/relatorios/{job}", response_class=HTMLResponse)
def ver_trabalho(job: str, request: Request, ctx=Depends(logado)):
    u, s = ctx
    t = _trabalho(job, u.id)
    if not t:
        return redir("/relatorios", erro="Relatório não encontrado ou expirado.")
    return render(request, "trabalho.html", {"job": job, "t": t}, u=u, s=s)


@app.get("/relatorios/{job}/pdf")
def baixar(job: str, ctx=Depends(logado)):
    u, s = ctx
    t = _trabalho(job, u.id)
    if not t or t["status"] != "pronto":
        raise HTTPException(404, "Relatório não encontrado ou expirado.")
    return Response(t["pdf"], media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{t["nome"]}"', "Cache-Control": "no-store"})


# ------------------------------------------------------------------ admin
def exigir_admin(ctx=Depends(logado)):
    u, s = ctx
    if not auth.eh_admin(u):
        raise HTTPException(403, "Acesso restrito.")
    return u, s


@app.get("/admin", response_class=HTMLResponse)
def admin(request: Request, ctx=Depends(exigir_admin), db=Depends(get_db)):
    u, s = ctx
    q = request.query_params.get("q", "").strip().lower()[:100]
    users = db.query(Usuario).order_by(Usuario.id.desc())
    if q:
        users = users.filter((Usuario.email.contains(q)) | (Usuario.loja_id == q) | (Usuario.loja_nome.ilike(f"%{q}%")))
    users = users.limit(200).all()
    linhas = []
    for x in users:
        a = acesso.assinatura_vigente(db, x)
        linhas.append({"u": x, "plano": (f"{a.tipo} até {a.pago_ate:%d/%m/%Y}" if a else "—"),
                       "usos": db.query(UsoRelatorio).filter(UsoRelatorio.usuario_id == x.id).count()})
    h = config.hoje()
    ini_mes = datetime(h.year, h.month, 1)
    stats = {"contas": db.query(Usuario).count(),
             "lojas": db.query(Usuario).filter(Usuario.loja_id.isnot(None)).count(),
             "ativas": db.query(Assinatura).filter(Assinatura.pago_ate >= h, Assinatura.status != "pendente").count(),
             "relatorios_mes": db.query(UsoRelatorio).filter(UsoRelatorio.criado_em >= ini_mes).count(),
             "gratis": db.query(SituacionalGratis).count(),
             "fila": _fila.qsize()}
    return render(request, "admin.html", {"linhas": linhas, "q": q, "stats": stats}, u=u, s=s)


@app.post("/admin/acao")
def admin_acao(request: Request, usuario_id: int = Form(...), acao: str = Form(...), valor: str = Form(""),
               csrf: str = Form(""), ctx=Depends(exigir_admin), db=Depends(get_db)):
    u, s = ctx
    auth.exigir_csrf(s, csrf)
    x = db.get(Usuario, usuario_id)
    if not x:
        return redir("/admin", erro="Conta não encontrada.")
    try:
        if acao == "desvincular":
            x.loja_id, x.loja_nome, x.loja_cidade, x.loja_uf = None, "", "", ""
            msg = "Loja desvinculada."
        elif acao == "creditos":
            x.creditos_avulsos = max(0, x.creditos_avulsos + int(valor or 0))
            msg = "Créditos ajustados."
        elif acao == "senha":
            if len(valor.strip()) < 8:
                return redir("/admin", erro="Digite a nova senha (mínimo 8 caracteres) no campo valor.")
            x.senha_hash = auth.hash_senha(valor.strip())
            msg = "Senha redefinida. Envie a senha ao cliente por um canal privado."
        elif acao == "bloquear":
            x.ativo = not x.ativo
            msg = "Conta " + ("reativada." if x.ativo else "bloqueada.")
        elif acao == "plano_manual":
            dias = int(valor or 30)
            db.add(Assinatura(usuario_id=x.id, tipo="loja", ciclo="MONTHLY", lojas=1, valor=0, status="ativa",
                              pago_ate=config.hoje() + timedelta(days=dias), asaas_id="manual"))
            msg = f"Plano liberado por {dias} dias."
        else:
            return redir("/admin", erro="Ação desconhecida.")
    except ValueError:
        return redir("/admin", erro="Valor inválido.")
    db.commit()
    return redir("/admin", ok=msg)
