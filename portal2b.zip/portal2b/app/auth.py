"""Senhas, sessões (uma por conta) e proteção CSRF."""
import hashlib, hmac, secrets, time
from datetime import datetime
from collections import defaultdict

from fastapi import Request, HTTPException

from . import config
from .db import Sessao, Usuario

COOKIE = "p2b_sessao"


def hash_senha(senha: str) -> str:
    sal = secrets.token_bytes(16)
    h = hashlib.scrypt(senha.encode(), salt=sal, n=2 ** 14, r=8, p=1, dklen=32)
    return f"scrypt${sal.hex()}${h.hex()}"


def confere_senha(senha: str, guardado: str) -> bool:
    try:
        _, sal, h = guardado.split("$")
        novo = hashlib.scrypt(senha.encode(), salt=bytes.fromhex(sal), n=2 ** 14, r=8, p=1, dklen=32)
        return hmac.compare_digest(novo.hex(), h)
    except Exception:
        return False


def abrir_sessao(db, usuario: Usuario) -> Sessao:
    """Login novo derruba as sessões anteriores: a conta é individual e não pode ficar aberta em vários aparelhos."""
    db.query(Sessao).filter(Sessao.usuario_id == usuario.id).delete()
    s = Sessao(token=secrets.token_urlsafe(32), usuario_id=usuario.id, csrf=secrets.token_urlsafe(24))
    db.add(s)
    db.commit()
    return s


def sessao_atual(request: Request, db):
    tok = request.cookies.get(COOKIE)
    if not tok:
        return None, None
    s = db.get(Sessao, tok)
    if not s:
        return None, None
    if (datetime.utcnow() - s.criado_em).days >= config.DIAS_SESSAO:
        db.delete(s)
        db.commit()
        return None, None
    u = db.get(Usuario, s.usuario_id)
    if not u or not u.ativo:
        return None, None
    return u, s


def exigir_csrf(sessao, enviado: str):
    if not sessao or not enviado or not hmac.compare_digest(sessao.csrf, enviado):
        raise HTTPException(400, "Formulário expirado. Recarregue a página e tente de novo.")


def eh_admin(u: Usuario | None) -> bool:
    return bool(u) and u.papel == "admin"


# limite simples de tentativas de login por IP (memória do processo)
_tentativas: dict[str, list[float]] = defaultdict(list)


def pode_tentar_login(*chaves, limite=8, janela=600) -> bool:
    """Limite por IP e por e-mail (o IP sozinho pode ser falsificado por cabeçalho)."""
    agora = time.time()
    if len(_tentativas) > 50_000:
        _tentativas.clear()
    ok = True
    for k in chaves:
        _tentativas[k] = [t for t in _tentativas[k] if agora - t < janela]
        ok = ok and len(_tentativas[k]) < limite
    return ok


def registrar_tentativa(*chaves):
    for k in chaves:
        _tentativas[k].append(time.time())
