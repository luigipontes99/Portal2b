"""Regras de acesso: quem pode gerar qual relatório e como ele é cobrado."""
from datetime import date, datetime

from . import config
from .db import Usuario, Assinatura, Franquia, SituacionalGratis, UsoRelatorio

TIPOS = {
    "situacional": "Relatório situacional (últimos 90 dias)",
    "fechamento": "Fechamento mensal",
    "periodo": "Relatório de período",
}


def assinatura_vigente(db, u: Usuario) -> Assinatura | None:
    """Assinatura própria (plano Loja) ou da franquia à qual a loja pertence, paga até hoje ou depois."""
    hoje = config.hoje()
    cands = db.query(Assinatura).filter(Assinatura.usuario_id == u.id, Assinatura.tipo == "loja").all()
    if u.franquia_id:
        f = db.get(Franquia, u.franquia_id)
        if f and f.assinatura_id:
            a = db.get(Assinatura, f.assinatura_id)
            if a:
                cands.append(a)
    for a in cands:
        if a.pago_ate and a.pago_ate >= hoje and a.status != "pendente":
            return a
    return None


def usos_no_mes(db, u: Usuario) -> int:
    h = config.hoje()
    ini = datetime(h.year, h.month, 1)
    return db.query(UsoRelatorio).filter(UsoRelatorio.usuario_id == u.id, UsoRelatorio.cobranca == "plano",
                                         UsoRelatorio.criado_em >= ini).count()


def situacional_gratis_disponivel(db, u: Usuario) -> bool:
    if u.loja_id:
        return db.get(SituacionalGratis, u.loja_id) is None
    # conta sem loja vinculada ainda: a checagem final é feita com o ID lido dos arquivos
    return db.query(SituacionalGratis).filter(SituacionalGratis.usuario_id == u.id).count() == 0


def forma_de_cobranca(db, u: Usuario, tipo: str) -> str | None:
    """Devolve 'gratis', 'plano' ou 'avulso' (na ordem de preferência), ou None se não pode gerar."""
    if tipo == "situacional" and situacional_gratis_disponivel(db, u):
        return "gratis"
    if assinatura_vigente(db, u) and usos_no_mes(db, u) < config.LIMITE_RELATORIOS_MES:
        return "plano"
    if u.creditos_avulsos > 0:
        return "avulso"
    return None


def gratis_ja_usado(db, loja_id: str, nome_norm: str) -> bool:
    if db.get(SituacionalGratis, loja_id):
        return True
    return bool(nome_norm) and db.query(SituacionalGratis).filter(SituacionalGratis.nome_norm == nome_norm).count() > 0


def cobrar(db, u: Usuario, loja_id: str, nome_norm: str, tipo: str, preferida: str) -> str:
    """Escolhe e reserva a cobrança no momento da entrega, de forma atômica. Levanta ValueError se não houver saldo."""
    from sqlalchemy import update
    ordem = [preferida] + [x for x in ("plano", "avulso") if x != preferida]
    for forma in ordem:
        if forma == "gratis":
            if tipo == "situacional" and not gratis_ja_usado(db, loja_id, nome_norm):
                db.add(SituacionalGratis(loja_id=loja_id, nome_norm=nome_norm, usuario_id=u.id))
                break
        elif forma == "plano":
            if assinatura_vigente(db, u) and usos_no_mes(db, u) < config.LIMITE_RELATORIOS_MES:
                break
        elif forma == "avulso":
            r = db.execute(update(Usuario).where(Usuario.id == u.id, Usuario.creditos_avulsos > 0)
                           .values(creditos_avulsos=Usuario.creditos_avulsos - 1))
            if r.rowcount == 1:
                break
    else:
        raise ValueError("sem saldo")
    db.add(UsoRelatorio(usuario_id=u.id, loja_id=loja_id, tipo=tipo, cobranca=forma))
    db.commit()
    return forma


def resumo_plano(db, u: Usuario) -> dict:
    a = assinatura_vigente(db, u)
    return {
        "assinatura": a,
        "usos_mes": usos_no_mes(db, u),
        "limite_mes": config.LIMITE_RELATORIOS_MES,
        "creditos": u.creditos_avulsos,
        "gratis": situacional_gratis_disponivel(db, u),
    }
