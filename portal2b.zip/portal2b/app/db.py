"""Banco de dados. Guarda só conta, loja vinculada, assinatura e contagem de uso.
Nenhum arquivo, número ou texto de relatório é gravado aqui."""
from datetime import datetime, date

from sqlalchemy import (create_engine, String, Integer, Float, Boolean, DateTime, Date, ForeignKey, Text)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, relationship

from . import config

engine = create_engine(config.DATABASE_URL, pool_pre_ping=True,
                       connect_args={"check_same_thread": False} if config.DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class Usuario(Base):
    __tablename__ = "usuarios"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    senha_hash: Mapped[str] = mapped_column(String(300))
    nome: Mapped[str] = mapped_column(String(200))
    telefone: Mapped[str] = mapped_column(String(40), default="")
    cpf_cnpj: Mapped[str] = mapped_column(String(20), default="")
    papel: Mapped[str] = mapped_column(String(20), default="cliente")  # cliente | gestor | admin
    # loja vinculada: definida no primeiro envio de arquivos e única no sistema
    loja_id: Mapped[str | None] = mapped_column(String(40), unique=True, nullable=True, index=True)
    loja_nome: Mapped[str] = mapped_column(String(200), default="")
    loja_cidade: Mapped[str] = mapped_column(String(100), default="")
    loja_uf: Mapped[str] = mapped_column(String(4), default="")
    franquia_id: Mapped[int | None] = mapped_column(ForeignKey("franquias.id"), nullable=True)
    creditos_avulsos: Mapped[int] = mapped_column(Integer, default=0)
    asaas_cliente_id: Mapped[str] = mapped_column(String(60), default="")
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Sessao(Base):
    __tablename__ = "sessoes"
    token: Mapped[str] = mapped_column(String(80), primary_key=True)
    usuario_id: Mapped[int] = mapped_column(ForeignKey("usuarios.id"), index=True)
    csrf: Mapped[str] = mapped_column(String(80))
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Assinatura(Base):
    __tablename__ = "assinaturas"
    id: Mapped[int] = mapped_column(primary_key=True)
    usuario_id: Mapped[int] = mapped_column(ForeignKey("usuarios.id"), index=True)  # quem paga
    tipo: Mapped[str] = mapped_column(String(20))  # loja | franquia
    ciclo: Mapped[str] = mapped_column(String(10))  # MONTHLY | YEARLY
    lojas: Mapped[int] = mapped_column(Integer, default=1)
    valor: Mapped[float] = mapped_column(Float)
    asaas_id: Mapped[str] = mapped_column(String(60), default="", index=True)
    status: Mapped[str] = mapped_column(String(20), default="pendente")  # pendente | ativa | atrasada | cancelada
    pago_ate: Mapped[date | None] = mapped_column(Date, nullable=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Franquia(Base):
    __tablename__ = "franquias"
    id: Mapped[int] = mapped_column(primary_key=True)
    nome: Mapped[str] = mapped_column(String(200))
    gestor_id: Mapped[int] = mapped_column(Integer, index=True)
    assinatura_id: Mapped[int | None] = mapped_column(ForeignKey("assinaturas.id"), nullable=True)
    lojas: Mapped[int] = mapped_column(Integer)
    convites = relationship("Convite", back_populates="franquia")


class Convite(Base):
    __tablename__ = "convites"
    codigo: Mapped[str] = mapped_column(String(20), primary_key=True)
    franquia_id: Mapped[int] = mapped_column(ForeignKey("franquias.id"), index=True)
    usado_por: Mapped[int | None] = mapped_column(Integer, nullable=True)
    usado_em: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    franquia = relationship("Franquia", back_populates="convites")


class SituacionalGratis(Base):
    """Uma loja do iFood só recebe o relatório situacional grátis uma vez, qualquer que seja a conta."""
    __tablename__ = "situacional_gratis"
    loja_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    nome_norm: Mapped[str] = mapped_column(String(200), default="", index=True)  # trava também pelo nome da loja
    usuario_id: Mapped[int] = mapped_column(Integer)
    usado_em: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class UsoRelatorio(Base):
    """Só a contagem: quem, qual loja, que tipo e quando. Nunca o conteúdo."""
    __tablename__ = "uso_relatorios"
    id: Mapped[int] = mapped_column(primary_key=True)
    usuario_id: Mapped[int] = mapped_column(Integer, index=True)
    loja_id: Mapped[str] = mapped_column(String(40), index=True)
    tipo: Mapped[str] = mapped_column(String(20))
    cobranca: Mapped[str] = mapped_column(String(20))  # gratis | plano | avulso
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class PagamentoAvulso(Base):
    __tablename__ = "pagamentos_avulsos"
    id: Mapped[int] = mapped_column(primary_key=True)
    usuario_id: Mapped[int] = mapped_column(Integer, index=True)
    asaas_id: Mapped[str] = mapped_column(String(60), default="", index=True)
    status: Mapped[str] = mapped_column(String(20), default="pendente")
    link: Mapped[str] = mapped_column(Text, default="")
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class EventoWebhook(Base):
    __tablename__ = "eventos_webhook"
    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    recebido_em: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


def criar_tabelas():
    Base.metadata.create_all(engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
