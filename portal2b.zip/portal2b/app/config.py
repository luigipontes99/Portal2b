"""Configuração do Portal 2b. Tudo vem de variáveis de ambiente (veja .env.example)."""
import os
from datetime import date, datetime
from zoneinfo import ZoneInfo

FUSO = ZoneInfo(os.getenv("FUSO", "America/Sao_Paulo"))


def hoje() -> date:
    """Data de hoje no horário de Brasília (o servidor roda em UTC)."""
    return datetime.now(FUSO).date()


def _bool(nome, padrao=False):
    v = os.getenv(nome)
    return padrao if v is None else v.strip().lower() in ("1", "true", "sim", "yes")


DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./portal2b.db")
if DATABASE_URL.startswith("postgres://"):  # Render/Heroku entregam neste formato
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

SECRET_KEY = os.getenv("SECRET_KEY", "troque-esta-chave-em-producao")
BASE_URL = os.getenv("BASE_URL", "http://localhost:8000").rstrip("/")
COOKIE_SECURE = _bool("COOKIE_SECURE", BASE_URL.startswith("https"))
# Admin: nunca pelo cadastro. Ou pelo comando "python -m app.criar_admin email senha", ou (servidor sem
# terminal, como o plano grátis do Render) pelas variáveis abaixo: na subida, se ainda não houver admin,
# a conta é criada. Depois de entrar, apague ADMIN_SENHA das variáveis.
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "").strip().lower()
ADMIN_SENHA = os.getenv("ADMIN_SENHA", "")

# IA
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
MODELO_EXTRACAO = os.getenv("MODELO_EXTRACAO", "claude-sonnet-5-5")
MODELO_REDACAO = os.getenv("MODELO_REDACAO", "claude-sonnet-5-5")
MOCK_IA = _bool("MOCK_IA", False)  # testes: não chama a API

# Asaas
ASAAS_API_KEY = os.getenv("ASAAS_API_KEY", "")
ASAAS_AMBIENTE = os.getenv("ASAAS_AMBIENTE", "sandbox")  # sandbox | producao
ASAAS_URL = "https://api.asaas.com/v3" if ASAAS_AMBIENTE == "producao" else "https://api-sandbox.asaas.com/v3"
ASAAS_WEBHOOK_TOKEN = os.getenv("ASAAS_WEBHOOK_TOKEN", "")
MOCK_ASAAS = _bool("MOCK_ASAAS", False)  # só para testes locais: ativa planos sem cobrar

# Marca e contato
EMPRESA = "2bProud Consultoria"
WHATSAPP = os.getenv("WHATSAPP", "5521979498333")
TELEFONE = os.getenv("TELEFONE", "(21) 97949-8333")
INSTAGRAM = os.getenv("INSTAGRAM", "@2b.proud")

# Preços (R$)
PRECO_LOJA_MENSAL = 119.00
PRECO_LOJA_ANUAL = 1068.00
FRANQUIA_FAIXAS = [(3, 5, 99.00), (6, 10, 89.00), (11, 10_000, 79.00)]  # (mín, máx, R$/loja/mês)
FRANQUIA_DESCONTO_ANUAL = 0.20
PRECO_AVULSO = 49.00
PRECO_LEITURA_CONSULTOR = 197.00
LIMITE_RELATORIOS_MES = 4
DIAS_TOLERANCIA = 3

# Arquivos enviados
MAX_ARQUIVOS = 30
MAX_MB_ARQUIVO = 10
MINUTOS_PDF_DISPONIVEL = 30
MAX_MB_ENVIO = 80  # soma de todos os arquivos de um envio
DIAS_SESSAO = 14


def preco_franquia_loja(lojas: int) -> float:
    for a, b, p in FRANQUIA_FAIXAS:
        if a <= lojas <= b:
            return p
    raise ValueError("Franquia a partir de 3 lojas")


def valor_franquia(lojas: int, ciclo: str) -> float:
    mensal = lojas * preco_franquia_loja(lojas)
    return round(mensal * 12 * (1 - FRANQUIA_DESCONTO_ANUAL), 2) if ciclo == "YEARLY" else round(mensal, 2)

# Quantos relatórios podem ser gerados ao mesmo tempo (cada um abre um Chromium; ~400 MB de RAM)
GERACOES_SIMULTANEAS = int(os.getenv("GERACOES_SIMULTANEAS", "1"))
