# Portal 2b: guia de publicação

Este guia leva o portal do código até o ar, sem precisar programar. Faça tudo primeiro em **modo de teste** (Asaas sandbox) e só depois troque para produção.

## O que o portal faz

- **Cadastro e login individual.** Ao entrar num aparelho, a sessão anterior cai.
- **Uma conta, uma loja.** A loja é lida dos próprios relatórios do iFood (coluna "Id da loja" do CSV de Vendas) no primeiro envio e fica travada na conta. Uma loja não pode estar em duas contas.
- **Relatório situacional grátis**, uma vez por loja (travado pelo ID e pelo nome da loja, não pelo e-mail).
- **Planos pagos pelo Asaas**:
  - Loja: R$ 119/mês ou R$ 1.068/ano.
  - Franquia: R$ 99, R$ 89 ou R$ 79 por loja, conforme a faixa; 20% de desconto no anual. Cada loja da franquia entra com um código de convite.
  - Relatório avulso: R$ 49.
  - Plano dá até 4 relatórios por mês.
- **Relatórios**: situacional (90 dias), fechamento mensal e período livre. Seguem o visual do fechamento 2bProud, com tom neutro (sem recomendações) e um convite para a leitura com consultor (R$ 197) no final.
- **Precificação**: três calculadoras (preço de venda, promoção e anúncio). As contas são feitas no navegador do cliente.
- **Nada do relatório fica salvo.**
  - Os arquivos são lidos na memória e apagados depois.
  - O PDF fica 30 minutos disponível para download e some.
  - O banco guarda só conta, loja vinculada, plano e a contagem de relatórios.
- **Admin** (só a sua conta): buscar clientes, dar créditos, liberar plano manual, redefinir senha, desvincular loja e bloquear conta.

## 0. Começar com custo fixo zero (recomendado no início)

O portal foi ajustado para caber em servidores de 512 MB (pico medido de ~450 MB ao gerar um relatório). Assim dá para começar sem custo fixo:

| Peça | Serviço grátis | Limitação |
|---|---|---|
| Site | Render, plano Free | "dorme" após 15 min sem acesso; o primeiro acesso depois disso leva ~1 min |
| Banco | Neon, plano Free (permanente) | 1 GB (sobra: o banco guarda só contas e contagens) |
| IA | paga por uso | só quando alguém gera relatório |

**Não use o Postgres grátis do Render**: ele é apagado 30 dias depois de criado. Use o Neon.

Para criar o banco no Neon:
1. Crie a conta em neon.com.
2. Crie um projeto (região São Paulo, se houver; senão, a mais próxima).
3. Copie a *connection string* (começa com `postgresql://`).
4. Cole-a na variável `DATABASE_URL` do Render.

**Quando trocar para pago:** quando tiver o primeiro cliente pagando, mude o site para o plano Starter do Render (US$ 7/mês). Ele não dorme, e assim o aviso de pagamento do Asaas nunca encontra o site desligado. Se aparecer erro de memória na geração, suba para o Standard (2 GB).

**IA ainda mais barata:** a leitura dos prints pode usar o modelo Haiku (`MODELO_EXTRACAO=claude-haiku-5-5`), que custa uma fração do Sonnet. Teste com 2 ou 3 relatórios reais e compare com o Sonnet antes de adotar. Se errar números, volte para o Sonnet.

## 1. Contas que você precisa criar

| Serviço | Para quê | Onde |
|---|---|---|
| GitHub | guardar o código | github.com |
| Render | hospedar o site e o banco | render.com |
| Anthropic Console | a IA que lê os prints e escreve os textos | console.anthropic.com |
| Asaas | cobrar as assinaturas | asaas.com (e sandbox.asaas.com para teste) |

No **Anthropic Console**:
1. Crie uma chave de API.
2. Coloque créditos.
3. Defina um **limite de gasto mensal** (Settings > Limits). Comece com US$ 50.
4. Peça ao comercial da Anthropic a **retenção zero de dados** (Zero Data Retention). Sem ela, a Anthropic guarda as requisições por um período, conforme a política dela. A aprovação é deles.

## 2. Subir o código para o GitHub

1. No GitHub, crie um repositório **privado** chamado `portal-2b`.
2. Clique em "Add file > Upload files".
3. Arraste o **conteúdo** da pasta `portal2b`: `app`, `tests`, `Dockerfile`, `render.yaml`, `requirements.txt`, `.dockerignore`, `.env.example` e este guia.
4. Clique em "Commit changes".

## 3. Criar o site no Render

1. No Render, clique em **New > Blueprint** e conecte o repositório `portal-2b`. O arquivo `render.yaml` cria o site no plano grátis. O banco é o do Neon (passo 0).
2. O Render pede as variáveis marcadas para preencher:
   - `DATABASE_URL`: a connection string do Neon.
   - `BASE_URL`: deixe `https://portal-2b.onrender.com` por enquanto. Depois troque pelo seu domínio.
   - `ANTHROPIC_API_KEY`: a chave do passo 1.
   - `ASAAS_API_KEY`: a chave do **sandbox** do Asaas (Minha conta > Integrações).
3. Espere o primeiro deploy (5 a 10 minutos). Abra `https://SEU-SITE.onrender.com/saude`: deve aparecer `{"ok":true}`.
4. **Crie seu login de administrador.** O plano grátis do Render não tem terminal, então o admin vem das variáveis:
   1. Preencha `ADMIN_EMAIL` com o seu e-mail e `ADMIN_SENHA` com uma senha de 10 ou mais caracteres. O portal cria a conta na subida.
   2. Entre no site com esses dados e confira que aparece "Admin" no menu.
   3. **Apague `ADMIN_SENHA`** das variáveis.

   O admin nunca é criado pelo cadastro, de propósito: assim ninguém se cadastra como admin antes de você.

Se o Blueprint reclamar do plano, escolha no painel do Render:
- **Site**: um plano com pelo menos 1 GB de RAM (o gerador de PDF abre um navegador).
- **Banco**: o Postgres mais barato.

## 4. Ligar o Asaas ao portal (webhook)

O webhook é o aviso automático do Asaas de que um pagamento caiu. É ele que libera o plano.

1. No Render, copie o valor de `ASAAS_WEBHOOK_TOKEN` (aba Environment). Ele foi gerado sozinho.
2. No Asaas (sandbox), vá em **Integrações > Webhooks** e crie um webhook:
   - URL: `https://SEU-SITE.onrender.com/webhooks/asaas`
   - Token de autenticação: o valor copiado no passo 1.
   - Eventos: cobranças (pagamento confirmado, recebido, vencido, estornado) e assinaturas (removida, inativada).
3. Ative o webhook.

## 5. Testar tudo no sandbox

1. Crie uma conta de cliente comum (outro e-mail, não o de admin).
2. Gere o **relatório situacional grátis** com os arquivos reais de uma loja que você atende, com autorização do dono.
3. Compare o PDF com o seu fechamento manual: os números precisam bater.
4. Assine o plano Loja. Na página do Asaas sandbox, simule o pagamento. Volte ao painel: o plano deve aparecer como pago.
5. Teste a franquia com 3 lojas: os 3 códigos aparecem no painel. Use um deles num cadastro novo.
6. Teste os erros esperados: arquivos de outra loja, período diferente, sem o CSV de Vendas.

## 6. Ir para produção

1. No Render, mude `ASAAS_AMBIENTE` para `producao` e `ASAAS_API_KEY` para a chave de **produção**.
2. Refaça o webhook no Asaas de produção, com a mesma URL e o mesmo token.
3. (Opcional) Domínio próprio:
   - No Render, em Settings > Custom Domain, adicione por exemplo `portal.2bproud.com.br`.
   - Troque `BASE_URL` para esse endereço.
4. Antes de abrir para clientes:
   - [ ] Termos de uso e política de privacidade revisados por um advogado. As páginas atuais são minutas.
   - [ ] Pedido de retenção zero feito à Anthropic.
   - [ ] Limite de gasto definido na Anthropic.
   - [ ] Pelo menos 3 relatórios reais conferidos contra os seus fechamentos manuais.

## Custos mensais (estimativa; confira os preços atuais em cada site)

| Item | Custo |
|---|---|
| Começo: Render Free + Neon Free | US$ 0 |
| Com clientes: Render Starter + Neon Free | US$ 7/mês |
| Se precisar de mais memória: Render Standard + Neon Free | US$ 25/mês |
| IA por relatório | cerca de R$ 3 a 10 (≈ US$ 0,50 a 1,50) |
| Asaas | Pix/boleto R$ 1,99; cartão ~3% + R$ 0,49 por cobrança |

No plano Starter, 1 assinante do plano Loja já paga a estrutura.

## Limites conhecidos (seja transparente com o cliente)

1. **A trava de loja não é à prova de fraude.**
   - Quem editar todos os CSVs à mão consegue trocar o ID e o nome.
   - O sistema exige ID e nome nos arquivos, confere com o nome que aparece nos prints, e trava o grátis por ID e por nome. Isso barra o uso comum, mas não um fraudador determinado.
   - Se uma loja for "sequestrada" por outra conta, desvincule no admin.
2. **A leitura de prints pela IA pode errar.**
   - O sistema confere o Financeiro (vendas − taxas − promoções + ajustes = líquido) e a ordem do funil. O que não fecha sai do relatório, com aviso.
   - Os números citados nos textos precisam existir nos dados, senão o texto é trocado por um texto padrão.
3. **O iFood muda os formatos de exportação de tempos em tempos.** Se um relatório parar de ser reconhecido, o arquivo `app/reports/planilhas.py` precisa de ajuste.
4. **Recuperação de senha é manual.** Não há envio de e-mail: o cliente pede pelo WhatsApp e você redefine no admin.
5. **PDFs prontos ficam só na memória.** Se o servidor reiniciar, quem não baixou precisa gerar de novo. O crédito só é descontado quando o PDF fica pronto.
6. **Uma instância só.** O portal roda em um processo, por causa da regra de não salvar nada. Atende bem dezenas de relatórios por hora. Para crescer além disso, o próximo passo é uma fila com armazenamento temporário criptografado.

## Para quem for mexer no código

```
pip install -r requirements.txt
MOCK_IA=1 MOCK_ASAAS=1 uvicorn app.main:app --reload     # roda local, sem gastar IA nem cobrar
python -m pytest -q tests                               # 12 testes ponta a ponta
```

- Pastas e arquivos:
  - `app/main.py`: rotas.
  - `app/acesso.py`: regras de cobrança e limites.
  - `app/billing.py`: Asaas.
  - `app/reports/`: leitura, IA, checagens e PDF.
  - `app/prompts/`: instruções da IA (método e tom).
- Preços, limites e modelos de IA ficam em `app/config.py` e nas variáveis de ambiente.
- `MODELO_EXTRACAO` e `MODELO_REDACAO` escolhem o modelo Claude. O padrão é o Sonnet, por custo.
