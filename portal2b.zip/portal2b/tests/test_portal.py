"""Testes ponta a ponta com IA e cobrança simuladas (MOCK_IA=1, MOCK_ASAAS=1)."""
import os, re, pathlib, tempfile

_tmp = tempfile.mkdtemp()
os.environ.update(DATABASE_URL=f"sqlite:///{_tmp}/t.db", MOCK_IA="1", MOCK_ASAAS="1", ASAAS_API_KEY="",
                  ASAAS_WEBHOOK_TOKEN="tok-teste", BASE_URL="http://testserver")

import pytest
from fastapi.testclient import TestClient

from app.main import app, TRABALHOS, _fila
from app.db import SessionLocal, Usuario, Assinatura, criar_tabelas
from app.reports import motor

FX = pathlib.Path(__file__).parent / "fixtures"
P90 = "16/07/2026 - 13/10/2026"


def arquivos(periodo=P90, loja="999999"):
    out = []
    for f in sorted(FX.iterdir()):
        b = f.read_bytes()
        if f.suffix == ".csv":
            b = b.decode().replace(P90, periodo).replace("999999", loja)
            if loja != "999999":
                b = b.replace("Loja Teste", f"Loja {loja}")
            b = b.encode()
        out.append(("arquivos", (f.name, b)))
    return out


def csrf(c, url="/painel"):
    return re.search(r'name="csrf" value="([^"]+)"', c.get(url).text).group(1)


def novo(email, codigo=""):
    c = TestClient(app)
    r = c.post("/cadastro", data={"nome": "Teste " + email, "email": email, "telefone": "91999999999", "senha": "senha1234",
                                  "senha2": "senha1234", "aceite": "1", "codigo": codigo}, follow_redirects=False)
    assert r.status_code == 303, r.text
    return c


def gerar(c, tipo="situacional", **campos):
    arqs = campos.pop("_arqs", None) or arquivos()
    dados = {"tipo": tipo, "csrf": csrf(c, "/relatorios"), **campos}
    if tipo == "situacional":
        dados.setdefault("fim", "2026-10-13")
    r = c.post("/relatorios", data=dados, files=arqs, follow_redirects=False)
    _fila.join()  # a geração roda numa fila própria; espera terminar
    return r


def ultimo_job(c):
    r = c.get("/relatorios")
    return re.findall(r'href="/relatorios/([\w-]+)"', r.text)


@pytest.fixture(autouse=True)
def limpo():
    TRABALHOS.clear()
    yield


def test_fluxo_situacional_gratis_e_trava():
    c = novo("ana@x.com")
    r = gerar(c)
    assert r.status_code == 303 and "/relatorios/" in r.headers["location"]
    job = r.headers["location"].rsplit("/", 1)[1]
    pag = c.get(f"/relatorios/{job}").text
    assert "Relatório pronto" in pag, pag
    pdf = c.get(f"/relatorios/{job}/pdf")
    assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF"
    db = SessionLocal()
    u = db.query(Usuario).filter_by(email="ana@x.com").one()
    assert u.loja_id == "999999" and u.loja_nome == "Loja Teste"
    db.close()
    # segundo situacional: sem plano nem crédito, vai para planos
    r = c.post("/relatorios", data={"tipo": "situacional", "fim": "2026-10-13", "csrf": csrf(c, "/relatorios")},
               files=arquivos(), follow_redirects=False)
    assert r.headers["location"].startswith("/planos")
    # outra conta tentando a mesma loja: bloqueada (e não ganha outro grátis)
    c2 = novo("bia@x.com")
    r = gerar(c2)
    job = r.headers["location"].rsplit("/", 1)[1]
    assert "já está vinculada a outra conta" in c2.get(f"/relatorios/{job}").text


def test_loja_e_periodo_errados():
    c = novo("caio@x.com")
    r = gerar(c, _arqs=arquivos(loja="555555"))
    job = r.headers["location"].rsplit("/", 1)[1]
    assert "Relatório pronto" in c.get(f"/relatorios/{job}").text
    # conta travada na 555555; arquivos de outra loja são recusados
    c.post("/avulso", data={"csrf": csrf(c), "cpf_cnpj": "52998224725"})
    r = gerar(c, _arqs=arquivos(loja="777777"))
    job = r.headers["location"].rsplit("/", 1)[1]
    assert "vinculada à loja" in c.get(f"/relatorios/{job}").text
    # período diferente do pedido
    r = gerar(c, _arqs=arquivos(periodo="01/01/2026 - 31/03/2026", loja="555555"))
    job = r.headers["location"].rsplit("/", 1)[1]
    assert "outro período" in c.get(f"/relatorios/{job}").text
    # crédito avulso não foi consumido pelas falhas
    db = SessionLocal()
    assert db.query(Usuario).filter_by(email="caio@x.com").one().creditos_avulsos == 1
    db.close()


def test_mistura_de_lojas_nos_arquivos():
    c = novo("duda@x.com")
    arqs = arquivos(loja="111111")
    nome, b = arqs[-1][1]
    arqs[-1] = ("arquivos", (nome, b.replace(b"111111", b"222222")))
    r = gerar(c, _arqs=arqs)
    job = r.headers["location"].rsplit("/", 1)[1]
    assert "mais de uma loja" in c.get(f"/relatorios/{job}").text


def test_plano_fechamento_limite_e_calculadora():
    c = novo("edu@x.com")
    assert "fazem parte do plano" in c.get("/precificacao").text
    c.post("/assinar", data={"ciclo": "MONTHLY", "csrf": csrf(c), "cpf_cnpj": "52998224725"})
    assert "Preço de venda no iFood" in c.get("/precificacao").text
    set_ = "01/09/2026 - 30/09/2026"
    ok = 0
    for _ in range(4):
        r = gerar(c, tipo="fechamento", mes="2026-09", _arqs=arquivos(periodo=set_, loja="333333"))
        job = r.headers["location"].rsplit("/", 1)[1]
        ok += "Relatório pronto" in c.get(f"/relatorios/{job}").text
    assert ok == 4
    r = gerar(c, tipo="fechamento", mes="2026-09", _arqs=arquivos(periodo=set_, loja="333333"))
    assert r.headers["location"].startswith("/planos")  # passou do limite de 4 no mês


def test_fechamento_sem_financeiro_do_mes():
    c = novo("fabi@x.com")
    c.post("/avulso", data={"csrf": csrf(c), "cpf_cnpj": "52998224725"})
    r = gerar(c, tipo="fechamento", mes="2026-06", _arqs=arquivos(periodo="01/06/2026 - 30/06/2026", loja="444444"))
    job = r.headers["location"].rsplit("/", 1)[1]
    assert "Falta o Financeiro de junho/2026" in c.get(f"/relatorios/{job}").text


def test_franquia_convites():
    g = novo("gestor@rede.com")
    g.post("/franquia", data={"nome": "Rede X", "lojas": "3", "ciclo": "YEARLY", "csrf": csrf(g), "cpf_cnpj": "11222333000181"})
    pag = g.get("/painel").text
    codigos = re.findall(r"<b>(2B-[A-Z0-9]{8})</b>", pag)
    assert len(codigos) == 3
    db = SessionLocal()
    a = db.query(Assinatura).filter_by(tipo="franquia").one()
    assert a.valor == round(3 * 99 * 12 * 0.8, 2) and a.status == "ativa"
    db.close()
    loja = novo("loja1@rede.com", codigo=codigos[0])
    assert "faz parte da franquia" in loja.get("/painel").text
    assert "Preço de venda no iFood" in loja.get("/precificacao").text
    # código usado não serve de novo
    c = TestClient(app)
    r = c.post("/cadastro", data={"nome": "X", "email": "loja9@rede.com", "senha": "senha1234", "senha2": "senha1234",
                                  "aceite": "1", "codigo": codigos[0]})
    assert "inválido ou já usado" in r.text


def test_sessao_unica():
    c1 = novo("gil@x.com")
    c2 = TestClient(app)
    c2.post("/entrar", data={"email": "gil@x.com", "senha": "senha1234"})
    assert c2.get("/painel", follow_redirects=False).status_code == 200
    assert c1.get("/painel", follow_redirects=False).status_code == 303  # sessão antiga caiu


def test_webhook():
    c = novo("hel@x.com")
    db = SessionLocal()
    u = db.query(Usuario).filter_by(email="hel@x.com").one()
    a = Assinatura(usuario_id=u.id, tipo="loja", ciclo="MONTHLY", lojas=1, valor=119, asaas_id="sub_1")
    db.add(a); db.commit()
    w = TestClient(app)
    corpo = {"id": "evt_1", "event": "PAYMENT_RECEIVED", "payment": {"id": "pay_1", "subscription": "sub_1", "dueDate": "2026-10-28"}}
    assert w.post("/webhooks/asaas", json=corpo).status_code == 401
    assert w.post("/webhooks/asaas", json=corpo, headers={"asaas-access-token": "tok-teste"}).json()["evento"] == "PAYMENT_RECEIVED"
    assert w.post("/webhooks/asaas", json=corpo, headers={"asaas-access-token": "tok-teste"}).json()["evento"] == "repetido"
    db.refresh(a)
    assert a.status == "ativa" and a.pago_ate.isoformat() == "2026-12-01"
    db.close()


def test_gratis_travado_tambem_pelo_nome():
    """Mudar só o ID no CSV não dá um segundo relatório grátis para a mesma loja."""
    c = novo("ivo@x.com")
    gerar(c, _arqs=arquivos(loja="121212"))
    c2 = novo("jo@x.com")
    arqs = arquivos(loja="121212")
    arqs = [(k, (n, b.replace(b",121212,", b",343434,"))) for k, (n, b) in arqs]
    r = gerar(c2, _arqs=arqs)
    job = r.headers["location"].rsplit("/", 1)[1]
    assert "já usou o relatório situacional grátis" in c2.get(f"/relatorios/{job}").text


def test_checagem_de_texto():
    perm = motor._tokens_permitidos({"x": {"texto": "R$ 1.234,56"}, "y": {"texto": "16,45%"}})
    assert motor.checar_texto(["Vendas de **R$ 1.234,56** e conversão de 16,45%."], perm) == []
    assert motor.checar_texto(["Vendas de R$ 9.999,00."], perm)
    assert motor.checar_texto(["Recomendamos rever as promoções."], perm)
    assert motor.checar_texto(["Cada R$ 1 gerou R$ 5 em vendas."], perm)


def test_admin():
    from app.criar_admin import criar
    criar("admin@2b.com", "senhaforte123")
    c = TestClient(app)
    c.post("/entrar", data={"email": "admin@2b.com", "senha": "senhaforte123"})
    assert "Administração" in c.get("/admin").text
    c2 = novo("comum@x.com")
    assert c2.get("/admin").status_code == 403


def test_chamada_real_da_ia_monta_requisicao(monkeypatch):
    """Sem gastar API: confere o formato da requisição e a leitura da resposta da ferramenta."""
    from app import config
    from app.reports import ia, ingest
    chamadas = []

    class Bloco:
        type = "tool_use"
        input = {"sumario": ["Texto."], "destaques": ["**A**."]}

    class Msgs:
        def create(self, **kw):
            chamadas.append(kw)
            return type("R", (), {"content": [Bloco()]})()

    monkeypatch.setattr(config, "MOCK_IA", False)
    monkeypatch.setattr(ia, "_cliente", lambda: type("C", (), {"messages": Msgs()})())
    arqs = ingest.carregar([("vendas.csv", (FX / "vendas.csv").read_bytes()), ("perfil.png", (FX / "perfil.png").read_bytes())], 10)
    ia.extrair(arqs, "contexto")
    kw = chamadas[-1]
    assert kw["tool_choice"] == {"type": "tool", "name": "registrar_dados"}
    tipos = [b["type"] for b in kw["messages"][0]["content"]]
    assert "image" in tipos and tipos[0] == "text"
    assert ia.redigir({"periodo": {"texto": "x"}})["sumario"] == ["Texto."]


def test_paginas_iniciais():
    c = TestClient(app)
    r = c.get("/")
    assert r.status_code == 200
    for t in ("portal", "iFood", "99 Food", "Precificação", 'href="/ifood"', 'href="/precificacao"'):
        assert t in r.text
    assert 'href="/99' not in r.text  # 99 Food ainda não tem área
    r = c.get("/ifood")
    assert r.status_code == 200 and "Gerar meu relatório situacional grátis" in r.text
    assert c.get("/precificacao", follow_redirects=False).status_code in (303, 307)  # pede login
